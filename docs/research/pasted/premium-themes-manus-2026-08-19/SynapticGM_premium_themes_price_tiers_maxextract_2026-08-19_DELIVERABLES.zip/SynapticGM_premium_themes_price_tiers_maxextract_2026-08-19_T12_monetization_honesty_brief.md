# T12 — Monetization Honesty Brief

> **Legal note.** I’m an AI, not a lawyer — this is a working product-analysis draft, not formal legal advice; have qualified counsel review before relying on it. This brief deliberately does not choose a legal policy or assert that another platform’s policy applies to SynapticGM.

## The honest offer

A theme card sells a clearly named cosmetic outcome. It must identify the price, whether the item is permanent or subscription-dependent, exactly which components are included, the currently available fallback if a component cannot load, and the fact that it is cosmetic only. Public storefronts describe preview, ownership, subscription-only use, bundle composition, partial ownership, and refundability/status labels as separate concepts [1] [2] [3]. The SynapticGM transfer is **SPECULATIVE**: surface those concepts in plain language without copying external UI or policy text.

| Moment | Say / show | Do not say / imply | Owner |
|---|---|---|---|
| Card | Price, kit name, material one-line, exact included texture/frame/fonts/dice/voice/turn elements, ownership badge | “Premium experience” without a component list | Product / design |
| Expanded preview | In-play panel, type sample, material dice, turn chrome, user-invoked Hear, accessibility/preference state | Marketing-only asset, soundtrack, animation, or lighting not present after equip | Design / engineering |
| Bundle | All included SKUs, individual equivalence, live saving, owned/partial-owned treatment | Saving that ignores previous ownership or conditional access | Product / commerce |
| Checkout | Price/currency/tax as applicable, ownership/subscription status, product policy link, non-functional statement | Borrowed refund window, permanent access if entitlement ends, urgency unsupported by fact | Commerce / **COUNSEL** |
| Post-purchase | Equipped/owned confirmation, restore/manage route, clear fallback diagnosis | “Unlocked” if a required component failed to apply | Engineering / support |

### Low-regret copy patterns

- “Includes: velvet surface, arch frame, title/prose font policy, Wine Obsidian dice, Nocturne voice preview, and turn chrome.”
- “Cosmetic only. Does not affect dice rolls, loot, stats, or story outcomes.”
- “Preview reflects the equipped kit at your current motion and accessibility preferences.”
- “You own this” or “Included while your membership is active,” only when those statements are factually true.
- “Some decorative effects are simplified in reduced-motion, high-contrast, or narrow-screen modes; the kit’s material and state language remain intact.”

### Hard restrictions

Do not claim that a theme improves rolls, story, personalization intelligence, survival, access to canonical facts, or any result. Do not write “best value” unless supported by live, reproducible arithmetic. Do not use dark-pattern urgency, hidden expiry, concealed duplicates, or a preview that exceeds applied quality. Do not promise refund rights, cancellation rights, tax treatment, consumer-law compliance, or cross-platform access without review.

### Counsel / payment-owner decisions

- [ ] Final product classification and jurisdiction-specific disclosures.
- [ ] Refund, cancellation, withdrawal, and digital-content-consent wording.
- [ ] Subscription entitlement, expiry, grace period, and restoration copy.
- [ ] VAT/GST/pricing and currency-display logic.
- [ ] Gift, bundle, partial-ownership, and duplicate-purchase treatment.
- [ ] Age/Kid Mode purchase controls and parental-consent mechanics.
- [ ] Voice/audio rights, availability, and accessibility obligations.

## References

[1]: https://support.discord.com/hc/en-us/articles/17162747936663-Shop-FAQ "Discord Shop FAQ — accessed 2026-08-19"
[2]: https://legal.epicgames.com/store/refund-policy "Epic Games Store Refund Policy — accessed 2026-08-19"
[3]: https://store.steampowered.com/steam_refunds/ "Steam Refunds — accessed 2026-08-19"
[4]: https://www.dndbeyond.com/posts/1003-how-to-customize-your-character-sheet-on-d-d "D&D Beyond customization article — accessed 2026-08-19"
[5]: https://blog.roll20.net/posts/introducing-the-new-roll20-dungeons-dragons-character-sheet/ "Roll20 sheet redesign — accessed 2026-08-19"
[6]: https://foundryvtt.com/packages/ "Foundry package directory — accessed 2026-08-19"
[7]: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum "W3C SC 1.4.3 — accessed 2026-08-19"
[8]: https://www.w3.org/WAI/WCAG21/Understanding/non-text-contrast.html "W3C SC 1.4.11 — accessed 2026-08-19"
[9]: https://www.w3.org/WAI/WCAG22/Understanding/use-of-color "W3C SC 1.4.1 — accessed 2026-08-19"
[10]: https://www.w3.org/WAI/WCAG22/Understanding/reflow "W3C SC 1.4.10 — accessed 2026-08-19"
[11]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion "MDN prefers-reduced-motion — accessed 2026-08-19"
[12]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/background-image "MDN background-image — accessed 2026-08-19"
[13]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@font-face/font-display "MDN font-display — accessed 2026-08-19"
[14]: https://web.dev/articles/animations-guide "web.dev CSS animation guide — accessed 2026-08-19"
