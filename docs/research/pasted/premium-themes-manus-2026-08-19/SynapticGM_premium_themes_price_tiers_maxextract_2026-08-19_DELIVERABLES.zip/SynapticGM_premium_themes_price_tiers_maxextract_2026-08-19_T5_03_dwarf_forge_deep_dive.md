# T5 — Dwarf / Forge

**Classification:** **SPECULATIVE SynapticGM transfer.** This is original, trope-level design guidance. It uses no protected names, art, crests, layouts, or lookalike UI. Public sources establish only the broader mechanisms that layered customisation, responsive fallbacks, and material effects can be treated as separate cosmetic components [4] [5] [6] [12].

## Premium reference pattern

The intended kit family is **Dwarf Forgehall**. Its recognition should begin with **soot stone, hammered brass, warm forge spark**, then continue through **hammer head, stone grid, heavy divider**, title restraint, and a **brass** dice read. A paid kit earns its price when these cues agree across background, raised panel, prose, turn chrome, dice tray, Shop preview, and the settings sample. The kit never buys new outcomes: all results, state labels, and interaction geometry remain stable.

A surface should be materially persuasive at phone and desktop size without adding semantic work. Use a solid, contrast-tested base as the reading field. Put low-frequency texture and edge treatment in a background or pseudo-element; retain a non-texture fallback because background images are decorative to assistive technology [12]. Limit motion to one optional, quiet ambient behaviour. Use a static or opacity-only replacement under `prefers-reduced-motion` [11] [14]. The visual signature must remain when motion, audio, and high-chroma accent are removed.

## Cheap recolour failure modes

The family collapses when it becomes **brown-orange fill with no surface change**. That diagnosis is not aesthetic nit-picking: it signals that the player is paying for a hue rather than a coherent system. It also makes false-family comparison impossible. The high-risk neighbours are **Orc Warcamp, Goblin Scrapheap, Ember Depths**. Test those simultaneously with the accent blurred; the rater should identify material and frame rather than merely “dark,” “bright,” “metal,” or “fantasy.”

Typography can deepen the material read but must not become the information architecture. Apply the kit display face only to a short title or chapter marker. Controls, tables, StateTx, correction evidence, and long prose use the declared body/UI fallback. The decoration must survive 200% text resizing and 320-CSS-pixel reflow without overlap or loss of action [10]. Normal text must meet 4.5:1 contrast, and significant non-text controls/indicators 3:1 [7] [8].

## Specific CSS-variable-compatible upgrade recipe

Route the work through the existing texture/frame attributes and `--sgm-*` tokens. Set a kit neutral `--sgm-surface-base`, `--sgm-surface-raised`, `--sgm-surface-reading`, `--sgm-ink-primary`, `--sgm-ink-muted`, and a narrow cosmetic accent token. Give the selected/owned/locked states their existing semantic token roles and use an icon, label, outline, or pattern as a second channel [9]. Use a `data-sgm-texture` recipe that places the opaque reading field below content and ornament outside the text field. Use `data-sgm-frame` to apply **hammer head, stone grid, heavy divider** on outer corners only. Render **brass** as at least three faceted planes plus readable faces, not a flat coloured hex.

The concrete direction is: **low-frequency stone grain; hammered bands; narrow brass edge; ember micro-accent only**. Do not make every panel look molten or use generic ‘fantasy runes’. The Shop’s thumbnail must be rendered by the same theme path as the equipped screen and show the actual font policy, dice material, corner coverage, and optional Hear control. It cannot show animation or textile depth that the kit fails to render in play.

## Completion checklist

| Check | Pass condition |
|---|---|
| Material | At least two visible surface cues beyond hue remain with accent desaturated. |
| Frame | The {frame} silhouette is visible at 320 CSS px without covering focus or labels. |
| Type | Display use is short; UI/body fallback passes 200% text and spacing override. |
| Dice | {dice} is identified by 4/5 raters from a closed material set; values remain legible. |
| False friends | {false} do not collapse in five-rater blurred-accent review. |
| Honesty | Shop preview and equipped screenshot match on all required components. |
| Accessibility | Normal text ≥4.5:1; significant control/indicator ≥3:1; no colour-only state. |

## References

[1]: https://support.discord.com/hc/en-us/articles/17162747936663-Shop-FAQ "Discord Shop FAQ — accessed 2026-08-19"
[2]: https://legal.epicgames.com/store/refund-policy "Epic Games Store Refund Policy — accessed 2026-08-19"
[3]: https://store.steampowered.com/steam_refunds/ "Steam Refunds — accessed 2026-08-19"
[4]: https://www.dndbeyond.com/posts/1003-how-to-customize-your-character-sheet-on-d-d "D&D Beyond customization article — accessed 2026-08-19"
[5]: https://blog.roll20.net/posts/introducing-the-new-roll20-dungeons-dragons-character-sheet/ "Roll20 sheet redesign — accessed 2026-08-19"
[6]: https://foundryvtt.com/packages/ "Foundry package directory — accessed 2026-08-19"
[7]: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum "W3C SC 1.4.3 — accessed 2026-08-19"
[8]: https://www.w3.org/WAI/WCAG21/Understanding/non-text-contrast.html "W3C SC 1.4.11 — accessed 2026-08-19"
[9]: https://www.w3.org/WAI/WCAG22/Understanding/use-of-color "W3C SC 1.4.1 — accessed 2026-08-19"
[10]: https://www.w3.org/WAI/WCAG22/Understanding/reflow "W3C SC 1.4.10 — accessed 2026-08-19"
[11]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion "MDN prefers-reduced-motion — accessed 2026-08-19"
[12]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/background-image "MDN background-image — accessed 2026-08-19"
[13]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@font-face/font-display "MDN font-display — accessed 2026-08-19"
[14]: https://web.dev/articles/animations-guide "web.dev CSS animation guide — accessed 2026-08-19"
