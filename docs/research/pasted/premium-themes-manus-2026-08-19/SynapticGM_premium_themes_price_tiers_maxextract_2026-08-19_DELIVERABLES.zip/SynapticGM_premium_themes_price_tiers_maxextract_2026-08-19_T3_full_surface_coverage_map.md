# T3 — Full Surface Coverage Map

Every row is a **SPECULATIVE SynapticGM implementation requirement**, constrained to the existing engine. Decorative CSS background layers must not carry essential information because assistive technology does not announce them [12].

| Surface | What changes per kit | What stays Integration / semantic | Existing hook | Gap to audit | Acceptance criterion |
|---|---|---|---|---|---|
| Palette | Material neutrals and restrained cosmetic accents | Canonical state meanings; labels/icons/patterns | --sgm-* palette | Audit state inventory | No cyan leak; contrast passes |
| Panel textures | Tokenized texture stack and solid base | Content backing/state text | data-sgm-texture | Audit gradient/mask fallback | Removed texture still leaves readable panel |
| Page/background atmosphere | Low-frequency field, vignette, edge treatment | Reading well/navigation landmarks | --sgm-* surface vars | Audit root selector | Background never carries meaning |
| Typography — UI | Display face in short headings only | Controls, labels, mechanics | --sgm-font-ui | Audit var/loading | 200% text has no clip/overlap |
| Typography — story prose | Legible prose face | StateTx/correction/evidence differentiation | --sgm-font-story | Audit prose coverage | Story font applies and remains readable |
| Frames/filigree | Corner family and divider rhythm | Focus ring/hit area/badge geometry | data-sgm-frame | Audit mobile rules | Two signature cues visible at 320px |
| Dice + tray FX | Faceted material; restrained tray rim | Numbers, odds, roll control | diceMaterial enum | Audit renderer props | Not flat fill; reduced motion works |
| TTS / voice | Named selection and user-invoked Hear | Mute, volume, availability state | Existing voice selector | Audit preview state | No autoplay; unavailable is explicit |
| Turn chrome | Frame/marker/tone around turn container | Turn order and active-state meaning | --sgm-* + frame | Audit component | Active turn survives greyscale |
| HUD accents | Small material trims/icons | Correction/canon/evidence/invention semantics | --sgm-* | Audit HUD scope | Markers remain label+shape based |
| Shop/Themes preview | Same material/font/dice/frame/voice render | Price, ownership, entitlement | SHOP_CATALOG + vars | Audit preview parity | Zero missing required kit parts |
| Adventurer card | Material backing and portrait/frame harmony | Identity/status/controls | texture + frame | Audit card root | Never appears as default skin |
| Paper-doll / sheet | Sheet material, header ornament, dividers | Field order, inputs, roll actions | vars + font | Audit roots | No control displacement |
| Journal | Prose face, paper, tabs/dividers | Pinned canon/correction/evidence/invention | vars + texture | Audit journal | State language survives print/forced colours |
| Inventory / drawers | Material drawer face and handles | Counts, actions, filters | --sgm-* | Audit portals | Counts/focus read on dark kits |
| Map chrome | Border, legend panel, controlled edge effect | Map controls, pins, labels | vars + frame | Audit overlay | No loss of marker clarity |
| Salvage / System | Small material identity, frame header | System messages/actions/severity | --sgm-* | Audit modal/portal | Semantic severity is unchanged |
| Settings hubs | Equipped sample, texture/frame swatch | Accessibility controls, ownership, apply action | SHOP_CATALOG + uiTheme | Audit settings | Honest preview with preference mode |

## References

[1]: https://support.discord.com/hc/en-us/articles/17162747936663-Shop-FAQ "Discord Shop FAQ — accessed 2026-08-19"
[2]: https://legal.epicgames.com/store/refund-policy "Epic Games Store Refund Policy — accessed 2026-08-19"
[3]: https://store.steampowered.com/steam_refunds/ "Steam Refunds — accessed 2026-08-19"
[4]: https://www.dndbeyond.com/posts/1003-how-to-customize-your-character-sheet-on-d-d "D&D Beyond customization article — accessed 2026-08-19"
[5]: https://blog.roll20.net/posts/introducing-the-new-roll20-dungeons-dragons-character-sheet/ "Roll20 sheet redesign — accessed 2026-08-19"
[6]: https://foundryvtt.com/packages/ "Foundry package directory — accessed 2026-08-19"
[7]: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum "W3C SC 1.4.3 — accessed 2026-08-19"
[8]: https://www.w3.org/WAI/WCAG21/Understanding/non-text-contrast.html "W3C SC 1.4.11 — accessed 2026-08-19"
[9]: https://www.w3.org/WAI/WCAG22/Understanding/use-of-color "W3C SC 1.4.1 — accessed 2026-08-19"
[10]: https://www.w3.org/WAI/WCAG22/Understanding/reflow "W3C SC 1.4.10 — accessed 2026-08-19"
[11]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion "MDN prefers-reduced-motion — accessed 2026-08-19"
[12]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/background-image "MDN background-image — accessed 2026-08-19"
[13]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@font-face/font-display "MDN font-display — accessed 2026-08-19"
[14]: https://web.dev/articles/animations-guide "web.dev CSS animation guide — accessed 2026-08-19"
