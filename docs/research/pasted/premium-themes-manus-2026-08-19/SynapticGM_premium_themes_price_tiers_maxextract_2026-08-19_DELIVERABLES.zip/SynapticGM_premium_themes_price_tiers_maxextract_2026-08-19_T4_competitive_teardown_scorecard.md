# T4 — Competitive Teardown Scorecard

**Research use only.** Product/domain names in this scorecard are citations, not SynapticGM content-bank labels. “Steal” means an IP-safe pattern; “refuse” means a prohibited transfer. Each row is limited to a public mechanism described by the cited source.

| Product / domain | Trope overlap | Material vs recolour | Typography | Frames | Dice/chrome | Preview honesty | Price signal | Steal | Refuse | Citation |
|---|---|---|---|---|---|---|---|---|---|---|
| Discord Shop | Shop cosmetics / bundle | Layered profile effect, ownership, preview | N/A | N/A | Preview and permanent/subscription distinction | Published price/membership states | Truthful ownership and partial-bundle labels | Do not copy UI or naming | [1] |
| Epic Store policy | Digital purchase disclosure | N/A | N/A | N/A | Refundability status labels | Policy/status signal | Visible policy route | Do not adopt its policy text | [2] |
| Steam refunds | Bundles / purchase rights | N/A | N/A | N/A | Usage and bundle conditions | Policy signal | Define product-specific rules clearly | Do not claim Steam rules apply | [3] |
| D&D Beyond sheet customisation | Layered sheet decoration | Portrait/frame/backdrop/theme layers | N/A | Digital dice as separate cosmetic selection | Cross-device fallback disclosed | Subscription/perk context | Layered controls; fallback disclosure | No artwork/layout/trade-dress copying | [4] |
| Roll20 sheet redesign | Responsive information sheet | N/A | Density modes, retained actions | N/A | Usability tests / collapsed panels | Product context | Test time-on-task and misclicks | No sheet layout copying | [5] |
| Foundry directory | Modular marketplace | Package categories | N/A | Visual effects as category | Metadata and compatibility | Premium/module labels | Explicit compatibility metadata | No modules/assets copied | [6] |
| WCAG 2.2 contrast | Accessibility benchmark | N/A | Readable type hierarchy | N/A | Contrast requirements | N/A | 4.5:1 normal text, 3:1 important UI | Do not use decorative exceptions for mechanics | [7] [8] |
| WCAG use of color | State semantics | N/A | N/A | N/A | Non-colour state cues | N/A | Labels/icons/patterns as second channel | No colour-only ownership/status | [9] |
| W3C reflow | Small-screen use | N/A | Text scaling/reflow | N/A | 320 CSS px / 200% text testing | N/A | Phone + zoom acceptance gate | No desktop-only frames | [10] |
| MDN background-image | CSS material layers | Gradient/layer capability | N/A | N/A | Background is nonsemantic | N/A | Material as decoration over solid fallback | No information in texture | [12] |
| MDN font-display | Web-font resilience | N/A | Fallback loading policy | N/A | Fallback/swap choices | N/A | Explicit readable fallback | No invisible or shifting critical text | [13] |
| web.dev animation guide | Motion restraint | N/A | N/A | Opacity/transform approach | Profiled, bounded animation | N/A | Small named-property effects | No blanket transition/all or needless will-change | [14] |

## References

[1]: https://support.discord.com/hc/en-us/articles/17162747936663-Shop-FAQ "Discord Shop FAQ — accessed 2026-08-19"
[2]: https://legal.epicgames.com/store/refund-policy "Epic Games Store Refund Policy — accessed 2026-08-19"
[3]: https://store.steampowered.com/steam_refunds/ "Steam Refunds — accessed 2026-08-19"
[4]: https://www.dndbeyond.com/posts/1003-how-to-customize-your-character-sheet-on-d-d "D&D Beyond customization article — accessed 2026-08-19"
[5]: https://blog.roll20.net/posts/introducing-the-new-roll20-dungeons-dragons-character-sheet/ "Roll20 sheet redesign — accessed 2026-08-19"
[6]: https://foundryvtt.com/packages/ "Foundry package directory — accessed 2026-08-19"
[7]: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum "W3C SC 1.4.3 — accessed 2026-08-19"
[8]: https://www.w3.org/WAI/WCAG21/Understanding/non-text-contrast.html "W3C SC 1.4.11 — accessed 2026-08-19"
[9]: https://www.w3.org/WAI/WCAG22/Understanding/use-of-color "W3C SC 1.4.1 — accessed 2026-08-19"
[10]: https://www.w3.org/WAI/WCAG22/Understanding/reflow "W3C SC 1.4.10 — accessed 2026-08-19"
[11]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion "MDN prefers-reduced-motion — accessed 2026-08-19"
[12]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/background-image "MDN background-image — accessed 2026-08-19"
[13]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@font-face/font-display "MDN font-display — accessed 2026-08-19"
[14]: https://web.dev/articles/animations-guide "web.dev CSS animation guide — accessed 2026-08-19"
