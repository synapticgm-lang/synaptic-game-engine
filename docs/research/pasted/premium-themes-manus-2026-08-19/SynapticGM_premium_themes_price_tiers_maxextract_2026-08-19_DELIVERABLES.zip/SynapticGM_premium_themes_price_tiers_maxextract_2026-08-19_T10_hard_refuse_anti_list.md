# T10 — Hard-Refuse Anti-List

These are **release-blocking future-pass bans**. A design may be visually attractive and still be refused if it violates one row.

| Ban | Refuse this | Why it is hard-refuse |
|---|---|---|
| Integration leakage | Teal / Integration cyan bleeding into paid kits, especially Undead, Merfolk, Cyborg | It destroys kit identity and implies a broken auto-heal path. |
| Display-face monoculture | Cinzel-everywhere or any single display face across unrelated kits | It collapses recognition and makes content harder to scan. |
| Hue-only theme | An accent swap without new material, frame, type/dice or surface coverage | It creates recolour-tax regret. |
| Incomplete sold kit | Missing dice, voice, font, or frame after equip | It is a preview-honesty failure. |
| Marketing-only premium | Shop preview looks richer than equipped play | It is a high-risk regret/refund trigger. |
| Flat material dice | Flat hex fill marketed as wood, bone, brass, velvet, etc. | It fails material recognition and completeness. |
| Mechanics-as-decoration | Decorative type, texture, or colour encodes critical mechanics | It breaches semantic state continuity. |
| Licensed lookalike | Licensed franchise name, crest, art, or distinctive UI lock-in | It breaches the content fence. |
| A11y exception | Premium effect lowers contrast, fails greyscale, ignores reduced motion | Premium does not override accessibility. |
| Kid Mode pressure | Autoplay, countdown pressure, noisy motion, ad-like prompts | It conflicts with Kid Mode product law. |
| Untracked fallback | Silent asset failure falls back to default cyan | It hides defects and breaks recognition. |
| False-family collapse | Nocturne, Infernal, Noir, Bone, Ossuary look alike | It invalidates material-based pricing. |

The first check in design review is not “does it look premium?” It is “does it preserve the state language, a truthful preview, material identity, and preference-resilient readability?” Public accessibility criteria reinforce the contrast, non-colour-state, reflow, and motion constraints [7] [8] [9] [10] [11].

## References

[1]: https://support.discord.com/hc/en-us/articles/17162747936663-Shop-FAQ "Discord Shop FAQ — accessed 2026-08-19"
[2]: https://legal.epicgames.com/store/refund-policy "Epic Games Store Refund Policy — accessed 2026-08-19"
[3]: https://store.steampowered.com/steam_refunds/ "Steam Refunds — accessed 2026-08-19"
[4]: https://www.dndbeyond.com/posts/1003-how-to-customize-your-character-sheet-on-d-d "D&D Beyond customization article — accessed 2026-08-19"
[5]: https://blog.roll20.net/posts/introducing-the-new-roll20-dungeons-dragons-character-sheet/ "Roll20 sheet redesign — accessed 2026-08-19"
[6]: https://foundryvtt.com/packages/ "Foundry package directory — accessed 2026-08-19"
[7]: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum "W3C SC 1.4.3 — accessed 2026-08-19"
[8]: https://www.w3.org/WAI/WCAG21/Understanding/non-text-contrast.html "W3C SC 1.4.11 — accessed 2026-08-19"
[9]: https://www.w3.org/WAI/WCAG22/Understanding/use-of-color "W3C SC 1.4.1 — accessed 2026-08-19"
[10]: https://www.w3.org/WAI/WCAG22/Understanding/reflow "W3C SC 1.4.10 — accessed 2026-08-19"
[11]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion "MDN prefers-reduced-motion — accessed 2026-08-19"
[12]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/background-image "MDN background-image — accessed 2026-08-19"
[13]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@font-face/font-display "MDN font-display — accessed 2026-08-19"
[14]: https://web.dev/articles/animations-guide "web.dev CSS animation guide — accessed 2026-08-19"
