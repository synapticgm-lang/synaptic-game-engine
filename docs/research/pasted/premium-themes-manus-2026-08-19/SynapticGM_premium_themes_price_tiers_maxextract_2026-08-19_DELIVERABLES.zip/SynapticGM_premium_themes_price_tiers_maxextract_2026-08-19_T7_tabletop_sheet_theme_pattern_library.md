# T7 — Tabletop Sheet Theme Pattern Library

This is a **pattern library**, not a visual-copy exercise. The public sources establish layered customisation, stable sheet information, and responsive density mechanisms [4] [5] [6]. All transfer recipes below are **SPECULATIVE SynapticGM design recommendations**.

| Pattern | Transferable recipe for Adventurer card / paper-doll / journal | Verified public mechanism | IP fence |
|---|---|---|---|
| Material reading field | Use textured outer surface and opaque writing/reading well | D&D Beyond publicly separates backdrop/theme from sheet content; public mobile limitation shows fallbacks matter [4]. | Do not copy art, sheet layout, branded labels, or crest. |
| Header ornament | One controlled title band, thin material divider, small kit corner | Digital sheets can keep stable information structure while varying decoration [4]. | Do not turn a header into a critical state container. |
| Section hierarchy | Body face, numeric alignment, repeated section labels, content density control | Roll20 describes testing collapsible information and card/list density [5]. | Do not copy field names/placement or proprietary UI patterns. |
| Frame family | Use kit corner grammar around sheet groups, not every field | Foundry publicly distinguishes sheets/modules/visual effects as composable categories [6]. | Do not replicate a marketplace module’s art/chrome. |
| Printable variant | Remove texture, retain ink rules and status text | Public sheet resources include printable/fillable paths [4]. | Do not promise print output until implemented. |
| Device fallback | Keep all information when backdrop/frame is unavailable | Public documentation identifies a mobile backdrop limitation [4]. | Do not hide controls or critical content on narrow screens. |
| Preview fidelity | Show actual compact and full sheet sample | Public store/help mechanisms establish preview and device contexts [1] [4]. | Do not use marketing-only mockups. |

## Definition: premium sheet

A premium sheet feels complete when it has a material outer field, an opaque readable working surface, a restrained title moment, section dividers with a repeated rhythm, aligned numeric/action areas, a visible frame family, and a matching dice/turn language. It is not a premium sheet if a texture hides a value, display type replaces legible UI text, fields move by theme, or a narrow viewport loses the same surface identity.

### Transfer checklist

- [ ] Keep navigation, fields, player correction, pinned canon, StateTx, evidence, and invention in the same semantic order.
- [ ] Apply texture outside or behind an opaque reading field; include print/high-contrast fallback.
- [ ] Keep one display face for headings and one legible body/UI family.
- [ ] Use card/list density or progressive disclosure without hiding primary action.
- [ ] Snapshot phone, tablet, desktop, print, forced colours, and 200% text.

## References

[1]: https://support.discord.com/hc/en-us/articles/17162747936663-Shop-FAQ "Discord Shop FAQ — accessed 2026-08-19"
[2]: https://legal.epicgames.com/store/refund-policy "Epic Games Store Refund Policy — accessed 2026-08-19"
[3]: https://store.steampowered.com/steam_refunds/ "Steam Refunds — accessed 2026-08-19"
[4]: https://www.dndbeyond.com/posts/1003-how-to-customize-your-character-sheet-on-d-d "D&D Beyond customization article — accessed 2026-08-19"
[5]: https://blog.roll20.net/posts/introducing-the-new-roll20-dungeons-dragons-character-sheet/ "Roll20 sheet redesign — accessed 2026-08-19"
[6]: https://foundryvtt.com/packages/ "Foundry package directory — accessed 2026-08-19"
[7]: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum "W3C SC 1.4.3 — accessed 2026-08-19"
[8]: https://www.w3.org/WAI/WCAG21/Understanding/non-text-contrast.html "W3C SC 1.4.11 — accessed 2026-08-19"
[9]: https://www.w3.org/WAI/WCAG22/Understanding/use-of-color "W3C SC 1.4.1 — accessed 2026-08-19"
[10]: https://www.w3.org/WAI/WCAG22/Understanding/reflow "W3C SC 1.4.10 — accessed 2026-08-19"
[11]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion "MDN prefers-reduced-motion — accessed 2026-08-19"
[12]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/background-image "MDN background-image — accessed 2026-08-19"
[13]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@font-face/font-display "MDN font-display — accessed 2026-08-19"
[14]: https://web.dev/articles/animations-guide "web.dev CSS animation guide — accessed 2026-08-19"
