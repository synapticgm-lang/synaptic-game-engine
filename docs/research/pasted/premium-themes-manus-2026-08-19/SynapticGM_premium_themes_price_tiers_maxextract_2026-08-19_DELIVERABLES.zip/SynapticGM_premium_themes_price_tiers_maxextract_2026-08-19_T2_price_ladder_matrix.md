# T2 — Price Ladder Matrix

The price bands are **SPECULATIVE SynapticGM shelf policy**, not a stated market average. The matrix transfers public disclosure patterns for previews, membership access, bundles, and partial ownership [1].

| Tier | Must-have visual deltas | Nice-to-have | Anti-patterns | Player regret triggers | Shelf mapping |
|---|---|---|---|---|---|
| Free default | Stable slate baseline; full state language | Try-on sample | Artificial degradation | Default feels broken | Integration Blue — Free |
| Mid-included | Material/frame/type accent; entitlement visible | Choice rotation | Hidden expiry | Temporary access looked permanent | Future included shelf; disclose terms |
| High-included | Broader library; complete preview controls | Audio-lite polish | Glow marketed as premium | No coherent material delta | Future High shelf; no advance promise |
| £2.99–£3.99 | Complete part or full kit; in-play preview | Before/after; Hear; dice close-up | Hue-only swap | Recolour tax; missing part | Phosphor/Goblin £2.99; listed kits £3.99 |
| £7.99–£9.99 | Complementary contents; count and saving shown | Collection try-on | Hidden duplicate arithmetic | Overlap or false bundle value | Ancestry Sampler £9.99; verify live math |

At checkout, show included components, price, ownership mode, subscription dependency, fallbacks, and the applicable policy. Public refund labels demonstrate clarity patterns; they do not determine SynapticGM’s policy [2] [3].

## References

[1]: https://support.discord.com/hc/en-us/articles/17162747936663-Shop-FAQ "Discord Shop FAQ — accessed 2026-08-19"
[2]: https://legal.epicgames.com/store/refund-policy "Epic Games Store Refund Policy — accessed 2026-08-19"
[3]: https://store.steampowered.com/steam_refunds/ "Steam Refunds — accessed 2026-08-19"
[4]: https://www.dndbeyond.com/posts/1003-how-to-customize-your-character-sheet-on-d-d "D&D Beyond customization article — accessed 2026-08-19"
[5]: https://blog.roll20.net/posts/introducing-the-new-roll20-dungeons-dragons-character-sheet/ "Roll20 sheet redesign — accessed 2026-08-19"
[6]: https://foundryvtt.com/packages/ "Foundry package directory — accessed 2026-08-19"
[7]: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum "W3C SC 1.4.3 — accessed 2026-08-19"
[8]: https://www.w3.org/WAI/WCAG21/Understanding/non-text-contrast.html "W3C SC 1.4.11 — accessed 2026-08-19"
[9]: https://www.w3.org/WAI/WCAG22/Understanding/use-of-color "W3C SC 1.4.1 — accessed 2026-08-19"
[10]: https://www.w3.org/WAI/WCAG22/Understanding/reflow "W3C SC 1.4.10 — accessed 2026-08-19"
[11]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion "MDN prefers-reduced-motion — accessed 2026-08-19"
[12]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/background-image "MDN background-image — accessed 2026-08-19"
[13]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@font-face/font-display "MDN font-display — accessed 2026-08-19"
[14]: https://web.dev/articles/animations-guide "web.dev CSS animation guide — accessed 2026-08-19"
