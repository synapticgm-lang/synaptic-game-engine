# T1 — Premium Theme Constitution

> **Mandatory store line:** “Cosmetic only. Does not affect dice rolls, loot, stats, or story outcomes.”

A SynapticGM theme is a **state-language skin**, not a mechanics switch. It may alter material, frame, type, motion, dice treatment, and audio flavour. It may never hide, remap, or make ambiguous player correction, pinned canon, StateTx, evidence, or invention. Content order, hit targets, result semantics, ownership semantics, and dice odds remain unchanged.

Premium means **materials over hue**. A £3.99 kit is a coherent rendered system: distinctive material, recognisable corner silhouette, restrained typography pairing, faceted dice material, optional Hear voice, and turn chrome across required surfaces. It fails if, with accent colour blurred, it could be mistaken for Integration Blue.

| Rule | Operational definition | Gate |
|---|---|---|
| Materials > hue | At least three non-hue cues: surface, frame, type, dice | 4/5 blurred-accent raters identify family |
| Complete kit | Texture, frame, font policy, dice, voice, turn treatment resolve | Zero missing required components |
| Honest Shop | Preview and play use same tokens and preference branch | Parity checklist passes |
| Semantic continuity | Labels/icons/patterns supplement colour | Greyscale and forced-colours pass |
| Accessible luxury | Effects are progressive enhancement | Contrast, reflow, reduced-motion gates pass |
| Kid Mode restraint | No pressure, autoplay, or decorative overload | Calm, readable default passes |

Public stores distinguish preview, ownership, subscription access, and bundle state; SynapticGM should disclose the equivalent accurately [1]. Refund conditions are product and payment-route specific, so no external policy is adopted here [2] [3]. **COUNSEL / payment-owner review** is required for any live purchase wording.

No parallel engine is authorized. Extend `SHOP_CATALOG`, `RACE_THEME_KITS`, `--sgm-*`, `data-sgm-texture`, `data-sgm-frame`, and kit auto-heal in `uiTheme.ts`. A load failure falls back to the kit’s neutral surface, not Integration cyan.

## References

[1]: https://support.discord.com/hc/en-us/articles/17162747936663-Shop-FAQ "Discord Shop FAQ — accessed 2026-08-19"
[2]: https://legal.epicgames.com/store/refund-policy "Epic Games Store Refund Policy — accessed 2026-08-19"
[3]: https://store.steampowered.com/steam_refunds/ "Steam Refunds — accessed 2026-08-19"
[4]: https://www.dndbeyond.com/posts/1003-how-to-customize-your-character-sheet-on-d-d "D&D Beyond customization article — accessed 2026-08-19"
[5]: https://blog.roll20.net/posts/introducing-the-new-roll20-dungeons-dragons-character-sheet/ "Roll20 sheet redesign — accessed 2026-08-19"
[6]: https://foundryvtt.com/packages/ "Foundry package directory — accessed 2026-08-19"
[7]: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum "W3C SC 1.4.3 — accessed 2026-08-19"
[8]: https://www.w3.org/WAI/WCAG21/Understanding/non-text-contrast.html "W3C SC 1.4.11 — accessed 2026-08-19"
[9]: https://www.w3.org/WAI/WCAG22/Understanding/use-of-color "W3C SC 1.4.1 — accessed 2026-08-19"
[10]: https://www.w3.org/WAI/WCAG22/Understanding/reflow "W3C SC 1.4.10 — accessed 2026-08-19"
[11]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion "MDN prefers-reduced-motion — accessed 2026-08-19"
[12]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/background-image "MDN background-image — accessed 2026-08-19"
[13]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@font-face/font-display "MDN font-display — accessed 2026-08-19"
[14]: https://web.dev/articles/animations-guide "web.dev CSS animation guide — accessed 2026-08-19"
