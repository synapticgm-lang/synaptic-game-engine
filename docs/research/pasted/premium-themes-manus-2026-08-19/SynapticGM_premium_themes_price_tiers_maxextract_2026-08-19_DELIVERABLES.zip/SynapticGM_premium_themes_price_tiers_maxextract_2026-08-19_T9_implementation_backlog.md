# T9 — SynapticGM Implementation Backlog

This backlog is deliberately constrained to `cosmeticCatalog.ts`, `index.css`, and `uiTheme.ts`. It does not propose a parallel theme engine. Effort is directional: **S** ≤1 focused day, **M** 2–4 focused days, **L** multi-surface / cross-component work; validate against the actual repository.

| ID | Priority | Item | Likely files | Acceptance test IDs | Effort | Depends on |
|---|---|---|---|---|---|---|
| P0-01 | P0 | Repair Vampire Nocturne material hierarchy and remove flat-maroon default | cosmeticCatalog.ts; index.css; uiTheme.ts | R01,R03,R05,R06,R13 | M | Token audit complete |
| P0-02 | P0 | Theme auto-heal reports and neutral-fallbacks for missing texture/frame/font/dice/voice | uiTheme.ts; cosmeticCatalog.ts | R04,R14 | M | Component availability map |
| P0-03 | P0 | Eliminate unintended Integration cyan/teal in paid-kit roots, portals and dice | index.css; uiTheme.ts | R02,R07,R13,R14 | M | Semantic token inventory |
| P0-04 | P0 | Make expanded Shop preview use equipped renderer/token path | cosmeticCatalog.ts; index.css; uiTheme.ts | R03 | L | Preview component audit |
| P0-05 | P0 | Declare and validate complete kit parts in catalog records | cosmeticCatalog.ts | R03,R04,R06,R12 | S | Catalog schema review |
| P1-01 | P1 | Fill Journal, map, sheet, inventory, System and Settings surface coverage gaps | index.css; uiTheme.ts | R03,R05,R07,R09 | L | Surface selector audit |
| P1-02 | P1 | Finish material dice and tray render recipes for every enum | index.css; cosmeticCatalog.ts | R06,R10 | M | Dice renderer hook |
| P1-03 | P1 | Font loading/fallback telemetry and no-layout-shift policy | index.css; uiTheme.ts | R04,R09 | M | Font asset manifests |
| P1-04 | P1 | Accessibility preference matrix: reflow, forced-colours, reduced-motion, Kid Mode | index.css; uiTheme.ts | R07-R12 | M | QA device matrix |
| P1-05 | P1 | Theme preview disclose component fallbacks/device limitation | cosmeticCatalog.ts; index.css | R03,R14 | S | Preview metadata |
| P2-01 | P2 | Bundle shelf polish: partial ownership, live saving, compatible components | cosmeticCatalog.ts; uiTheme.ts | R03 | M | Commerce facts / counsel |
| P2-02 | P2 | Seasonal cosmetic rotations with expiry/access copy | cosmeticCatalog.ts | R03,R12 | M | Entitlement model |
| P2-03 | P2 | Audio-lite stingers, only user-invoked and preference-aware | index.css; uiTheme.ts | R10,R12 | M | Audio policy |
| P2-04 | P2 | Advanced ambient motion after profiling | index.css | R10,R11 | M | Performance profile |

### Delivery order

Start P0-05 and P0-02 together so the catalog can declare components and auto-heal can make failures visible. Then execute P0-01/P0-03 with actual screenshots. P0-04 comes before charging for or promoting any kit whose preview cannot prove parity. Do not schedule advanced animation before P1 accessibility preferences and P1 surface coverage are closed.

## References

[1]: https://support.discord.com/hc/en-us/articles/17162747936663-Shop-FAQ "Discord Shop FAQ — accessed 2026-08-19"
[2]: https://legal.epicgames.com/store/refund-policy "Epic Games Store Refund Policy — accessed 2026-08-19"
[3]: https://store.steampowered.com/steam_refunds/ "Steam Refunds — accessed 2026-08-19"
[4]: https://www.dndbeyond.com/posts/1003-how-to-customize-your-character-sheet-on-d-d "D&D Beyond customization article — accessed 2026-08-19"
[5]: https://blog.roll20.net/posts/introducing-the-new-roll20-dungeons-dragons-character-sheet/ "Roll20 sheet redesign — accessed 2026-08-19"
[6]: https://foundryvtt.com/packages/ "Foundry package directory — accessed 2026-08-19"
[7]: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum "W3C SC 1.4.3 — accessed 2026-08-19"
[8]: https://www.w3.org/WAI/WCAG21/Understanding/non-text-contrast.html "W3C SC 1.4.11 — accessed 2026-08-19"
[9]: https://www.w3.org/WAI/WCAG22/Understanding/use-of-color "W3C SC 1.4.1 — accessed 2026-08-19"
[10]: https://www.w3.org/WAI/WCAG22/Understanding/reflow "W3C SC 1.4.10 — accessed 2026-08-19"
[11]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion "MDN prefers-reduced-motion — accessed 2026-08-19"
[12]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/background-image "MDN background-image — accessed 2026-08-19"
[13]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@font-face/font-display "MDN font-display — accessed 2026-08-19"
[14]: https://web.dev/articles/animations-guide "web.dev CSS animation guide — accessed 2026-08-19"
