# T14 — What Manus Still Cannot Know

The public research and supplied catalog are enough to make a strong original design and QA plan; they cannot prove the current product state, legal/commercial facts, or player reaction. The following are explicit unknowns, not invented findings.

| Unknown | Why it cannot be inferred | Evidence required | Owner |
|---|---|---|---|
| Live screenshots/video | Whether each listed surface currently restyles; exact appearance of teal bleed and flat-maroon failure | Before/after capture at desktop/phone with default, greyscale, reduced-motion, forced-colours | John / design |
| Repository access | Actual variable names, root selectors, portals, dice renderer, font manifest, voice API | Read-only code review of cosmeticCatalog.ts, index.css, uiTheme.ts | Engineering |
| Commerce facts | Actual GBP display, VAT/GST, Stripe/payment route, refund/cancellation terms, entitlement model | Approved source of truth and legal/commercial review | Product / finance / counsel |
| Metrics | Conversion, attach, refund, chargeback, preview engagement, kit usage, churn | Instrumented event definitions and a privacy review | Analytics / product |
| Voice facts | Voice availability, rights, latency, transcript/caption support, Kid Mode behaviour | Audio feature inventory and rights/accessibility review | Audio / counsel |
| Accessibility validation | Actual contrast compositing, keyboard order, screen-reader labels, browser/device support | Manual assistive-tech and device testing plus automated checks | Accessibility QA |
| User research | Whether material recognition works with target players; which false friends are common | Five-rater test per kit, diverse accessibility needs included | Research / John |
| Asset provenance | Whether every font/dice/texture is licensed and available in all deployment contexts | Asset manifest and licence evidence | Production / counsel |
| Bundle mathematics | Live individual prices, ownership handling, currency rounding, discounts | Live commerce calculation test | Commerce |
| Policy decisions | Subscription inclusion, expiry, gifting, restorative access, regional availability | Written product/policy decisions approved before copy | Product / counsel |

## Minimum evidence pack for John tonight

1. Ten screenshots per target kit: Shop expanded preview, equipped panel, Sheet, Journal, Map, dice tray, active turn, Settings, 320px view, and 200%-text view.
2. A current theme token dump from `cosmeticCatalog.ts`, `index.css`, and `uiTheme.ts`, including all auto-heal states.
3. A one-minute mute/unmute/Hear capture for each voice and the Kid Mode/reduced-motion behaviours.
4. A current, approved table of pricing, entitlement, policy, tax, and bundle rules.
5. Five-rater raw responses using the included CSV for Nocturne, Infernal, Noir, Bone Reliquary, and Ossuary first.

> **Rule:** Do not turn an unknown into a design claim. Attach the evidence, update the harness, then promote a recommendation to implementation.
