# T13 — Evaluation Harness Notes

`SynapticGM_premium_themes_price_tiers_maxextract_2026-08-19_T13_eval_harness.json` is the machine-readable gate file. It maps every supplied catalog theme key to declared material tokens, all required surfaces, state semantics, and test IDs. Values are an **original QA contract** inferred from the supplied catalog, not a statement that those components already resolve in the live build.

## Interpretation

- A kit fails if any required asset/token is absent, even if the panel has a new accent.
- A kit fails if it falls back to Integration cyan rather than its own neutral fallback.
- A kit fails if a semantic state becomes colour-only, is hidden by ornament, or moves from its canonical location.
- A kit fails if the Shop preview does not render the same required set as equipped play.
- A kit fails if required accessibility/preference tests fail; premium content receives no exception.

The contrast/reflow/motion gates reflect public W3C and MDN guidance [7] [8] [9] [10] [11].

## References

[1]: https://support.discord.com/hc/en-us/articles/17162747936663-Shop-FAQ "Discord Shop FAQ — accessed 2026-08-19"
[2]: https://legal.epicgames.com/store/refund-policy "Epic Games Store Refund Policy — accessed 2026-08-19"
[3]: https://store.steampowered.com/steam_refunds/ "Steam Refunds — accessed 2026-08-19"
[4]: https://www.dndbeyond.com/posts/1003-how-to-customize-your-character-sheet-on-d-d "D&D Beyond customization article — accessed 2026-08-19"
[5]: https://blog.roll20.net/posts/introducing-the-new-roll20-dungeons-dragons-character-sheet/ "Roll20 sheet redesign — accessed 2026-08-19"
[6]: https://foundryvtt.com/packages/ "Foundry package directory — accessed 2026-08-19"
[7]: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum "W3C SC 1.4.3 — accessed 2026-08-19"
[8]: https://www.w3.org/WAI/WCAG21/Understanding/non-text-contrast.html "W3C SC 1.4.11 — accessed 2026-08-19"
[9]: https://www.w3.org/WAI/WCAG22/Understanding/use-of-color "W3C SC 1.4.1 — accessed 2026-08-19"
[10]: https://www.w3.org/WAI/WCAG22/Understanding/reflow "W3C SC 1.4.10 — accessed 2026-08-19"
[11]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion "MDN prefers-reduced-motion — accessed 2026-08-19"
[12]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/background-image "MDN background-image — accessed 2026-08-19"
[13]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@font-face/font-display "MDN font-display — accessed 2026-08-19"
[14]: https://web.dev/articles/animations-guide "web.dev CSS animation guide — accessed 2026-08-19"
