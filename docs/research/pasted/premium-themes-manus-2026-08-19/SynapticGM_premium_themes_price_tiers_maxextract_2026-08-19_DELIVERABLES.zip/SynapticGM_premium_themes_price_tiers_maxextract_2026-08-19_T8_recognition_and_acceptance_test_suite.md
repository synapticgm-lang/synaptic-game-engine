# T8 — Recognition and Acceptance Test Suite

The suite operationalises the supplied recognition rule and accessibility gates. W3C publishes 4.5:1 normal-text and 3:1 large-text thresholds; important non-text UI requires 3:1 [7] [8]. Colour must not be the only state channel [9]. Reflow and motion preferences require real device/preference tests [10] [11].

## Protocol: “name it with accent blurred”

Prepare a 1080px and a phone-width screenshot for each kit showing background, raised panel, title, prose, frame corner, dice tray, and active-turn segment. Create an accent-neutral version by desaturating only the named cosmetic accent while retaining luminance/contrast. Recruit five independent raters who have not seen the answer key; randomise screenshots; give a closed set of kit-family labels plus “cannot tell.” Do not coach. A kit passes at four correct answers, with no more than one false-friend answer. Record the image filename, build SHA, preference mode, rater answers, and raw comments.

| ID | Test | Method | Pass bar | Hard stop | Area |
|---|---|---|---|---|---|
| R01 | Accent-blurred naming | Five independent raters; remove/neutralise accent hue; show material/frame/type/dice screenshot | ≥4/5 intended-family answers; ≤1 false friend | No | Kit identity |
| R02 | Greyscale state language | Monochrome screenshot of selected/owned/locked/correction/canon/evidence/invention | ≥4/5 recover every state from label/icon/pattern/shape | No | Semantics |
| R03 | Preview parity | Compare Shop preview and equipped play on listed required components | 0 missing required components; same motion preference branch | No | Honesty |
| R04 | Font completeness | Disable cache / inspect loading and fallback; exercise story prose | UI and story face resolve or labelled fallback; no reflow break | No | Completeness |
| R05 | Phone frame | 320 CSS px and 200% text | Two signature corner cues visible; no label/focus obstruction | No | Responsive |
| R06 | Dice material | Normal-size dice shown to five raters from closed set | ≥4/5 material choice; numeric face legible | No | Completeness |
| R07 | Contrast | Measure actual composited text/control states | Normal text ≥4.5:1; significant non-text UI ≥3:1 | No | Accessibility |
| R08 | Non-colour semantics | Remove colour / inspect selected, warning, owned, active | No essential meaning dependent on hue alone | No | Accessibility |
| R09 | Text scale/reflow | 200% text; 320 CSS px; spacing override | No clip, overlap, loss, or two-axis UI scroll except justified canvas | No | Accessibility |
| R10 | Reduced motion | `prefers-reduced-motion: reduce` plus Kid Mode | No looping shimmer/parallax/essential motion; identity still recognisable | No | Accessibility |
| R11 | Forced colours | `forced-colors: active` / platform high contrast | Focus, selected, locked, action states remain clear | No | Accessibility |
| R12 | Voice / Hear | Navigate kit cards muted and unmuted | No autoplay; Hear works or clearly reports unavailable | No | Accessibility |
| R13 | False friends | Compare Nocturne/Infernal/Noir/Bone Reliquary/Ossuary | No pair collapses for ≥4/5 raters | No | Differentiation |
| R14 | Auto-heal | Simulate missing font/frame/dice/voice | Kit neutral fallback is shown; no cyan leak; diagnostic exposed | No | Resilience |

## Shop chip delta

**Defined X = zero missing mandatory components.** A Shop chip may be simplified, but the expanded preview must match equipped play in texture, frame, UI font policy, story font policy, dice material, voice preview state, turn chrome, and motion preference. Pixel-perfect equality is not required across breakpoint; a missing material or a marketing-only effect is a failure.

## References

[1]: https://support.discord.com/hc/en-us/articles/17162747936663-Shop-FAQ "Discord Shop FAQ — accessed 2026-08-19"
[2]: https://legal.epicgames.com/store/refund-policy "Epic Games Store Refund Policy — accessed 2026-08-19"
[3]: https://store.steampowered.com/steam_refunds/ "Steam Refunds — accessed 2026-08-19"
[4]: https://www.dndbeyond.com/posts/1003-how-to-customize-your-character-sheet-on-d-d "D&D Beyond customization article — accessed 2026-08-19"
[5]: https://blog.roll20.net/posts/introducing-the-new-roll20-dungeons-dragons-character-sheet/ "Roll20 sheet redesign — accessed 2026-08-19"
[6]: https://foundryvtt.com/packages/ "Foundry package directory — accessed 2026-08-19"
[7]: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum "W3C SC 1.4.3 — accessed 2026-08-19"
[8]: https://www.w3.org/WAI/WCAG21/Understanding/non-text-contrast.html "W3C SC 1.4.11 — accessed 2026-08-19"
[9]: https://www.w3.org/WAI/WCAG22/Understanding/use-of-color "W3C SC 1.4.1 — accessed 2026-08-19"
[10]: https://www.w3.org/WAI/WCAG22/Understanding/reflow "W3C SC 1.4.10 — accessed 2026-08-19"
[11]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion "MDN prefers-reduced-motion — accessed 2026-08-19"
[12]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/background-image "MDN background-image — accessed 2026-08-19"
[13]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@font-face/font-display "MDN font-display — accessed 2026-08-19"
[14]: https://web.dev/articles/animations-guide "web.dev CSS animation guide — accessed 2026-08-19"
