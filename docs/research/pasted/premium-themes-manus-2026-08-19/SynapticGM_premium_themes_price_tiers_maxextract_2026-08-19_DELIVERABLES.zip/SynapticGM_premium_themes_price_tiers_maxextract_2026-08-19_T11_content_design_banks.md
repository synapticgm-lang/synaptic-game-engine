# T11 — Original Content / Design Banks

**Original-only bank.** All entries are trope-level SynapticGM directions; none is a licensed name, crest, place, series, or asset request. CSS gradients and background layers are technically available, but background imagery remains decorative and needs a solid fallback [12]. Use named-property transitions and a reduced-motion branch; prefer opacity/transform and profile effects [11] [14].

## Per-kit material line and never-line

| Kit | Material one-liner | Never-line |
|---|---|---|
| Integration Blue | cold slate registrar; square registrar silhouette; holo dice; Cold Registrar voice. | Do not treat cyan as a paid-kit fallback. |
| Neon Protocol | black lacquer and bounded electric channel; broken signal silhouette; neon dice; Street Chronicler voice. | Do not make the whole panel glow or flash. |
| Parchment Ledger | warm fibrous matte and archival ink; ledger tab silhouette; ivory dice; Grizzled Mentor voice. | Do not stain or texture writable content. |
| Bone Reliquary | ash, mineral dust and dry bone; reliquary notch silhouette; bone dice; Grizzled Mentor voice. | Do not add teal or clean velvet. |
| Phosphor Terminal | near-black CRT bloom and quiet scanline; terminal bracket silhouette; neon dice; Cold Registrar voice. | Do not flicker text, dice numbers, or semantic indicators. |
| Noir Crimson | matte charcoal paper and a single crimson interruption; case-file corner silhouette; obsidian dice; Street Chronicler voice. | Do not turn every crimson cue into an alert. |
| Glass Spire | frosted plane with opaque reading well; split glass bevel silhouette; frost dice; Cold Registrar voice. | Do not put critical copy on translucency. |
| Ember Depths | charcoal rock and restrained ember fissure; cut-stone silhouette; ember dice; Forge Deep voice. | Do not make it indistinguishable from Infernal. |
| Wood Elf Grove | mossy wood and leaf-shadow; vine silhouette; wood dice; Grove Whisper voice. | Do not use generic green fill as identity. |
| Dark Elf Umbrance | dusk textile and dark thread; filigree silhouette; obsidian dice; Under-Realm voice. | Do not make it a High Elf or Fae recolour. |
| High Elf Spire | ivory stone and silver line; ivory step silhouette; ivory dice; Lofty Court voice. | Do not reuse its display face across the shelf. |
| Dwarf Forgehall | soot stone and hammered brass; hammer / stone-grid silhouette; brass dice; Forge Deep voice. | Do not flatten it to brown-orange metal. |
| Orc Warcamp | rough iron and weathered canvas; spike / stud silhouette; iron dice; Warcamp voice. | Do not confuse rugged mass with scrap clutter. |
| Dragon Hoard | layered scale enamel and aged-gold glint; multi-row scale silhouette; scale dice; Hoard Rumble voice. | Do not tile scales across every field. |
| Phoenix Ashrise | charcoal rock and restrained ember fissure; feather-flame silhouette; ember dice; Ashrise voice. | Do not make it indistinguishable from Infernal. |
| Cyborg Chassis | brushed chassis and clipped circuit trace; mechanical chamfer silhouette; circuit dice; Chassis Synth voice. | Do not let Integration cyan become the only tech cue. |
| Angelic Radiance | diffuse pearl and warm rim; halo arc silhouette; marble dice; Radiance voice. | Do not wash out contrast with light. |
| Infernal Pact | charred paper and local sulfur heat; wax seal / broken edge silhouette; sulfur dice; Pact Heat voice. | Do not use velvet/wine or broad lava animation. |
| Undead Ossuary | ash, mineral dust and dry bone; knuckle-bone silhouette; bone dice; Ossuary voice. | Do not add teal or clean velvet. |
| Fae Glamour | iridescent veil and twilight bloom; unclosed curved corner silhouette; iridescent dice; Glamour voice. | Do not use random rainbow noise. |
| Goblin Scrapheap | dry scrap plates and rivet cadence; rivet / bolt silhouette; scrap dice; Scrap Cackle voice. | Do not become a Warcamp recolour. |
| Merfolk Abyss | deep tide contour and pearl glint; tide curl silhouette; tide dice; Abyss Tide voice. | Do not erase focus or pins with water effects. |
| Vampire Nocturne | flocked velvet, wine edge and moonlit obsidian; pointed gothic arch silhouette; velvet dice; Nocturne voice. | Do not use bone, wax seal, or flat maroon panels. |

## Twenty CSS-safe texture recipe sketches

| Existing ThemeTexture token | Recipe name | Layer stack: base → material → vignette/mask |
|---|---|---|
| plain | Plain | Solid slate base; very low-contrast linear lift; no noise; square inset border. |
| moss | Moss | Dark moss base; two radial leaf-shadow layers outside reading well; 3% fibre noise; vine-corner mask. |
| dusk | Dusk | Blue-black textile base; diagonal thread gradient at 4% opacity; deep vignette; filigree corner mask. |
| soot | Soot | Charcoal base; broad ash gradient; 2% mineral speckle; stone-grid corner mask. |
| ivory | Ivory | Warm ivory base; vertical mineral band; sparse silver hairline; stepped-corner mask. |
| banner | Banner | Canvas matte base; muted warp/weft repeat; narrow shadow fold; broad-stud corner mask. |
| scale | Scale | Deep enamel base; repeating offset arcs at low opacity; aged-gold edge glint; multi-row corner mask. |
| ember | Ember | Charcoal rock base; one narrow orange fissure gradient; soot vignette; cut-stone or feather mask. |
| circuit | Circuit | Graphite base; repeating orthogonal lines; one clipped emissive trace; chamfer mask. |
| halo | Halo | Opaque pale base; large warm radial rim outside text; subtle marble vein; halo-arc mask. |
| sulfur | Sulfur | Dry char base; local ochre hotspot; hairline crack overlay; broken-edge/seal mask. |
| bone | Bone | Ash base; off-white fleck layer; restrained crack line; knuckle/reliquary corner mask. |
| glamour | Glamour | Twilight base; two soft hue-shift gradients at low saturation; faint prism line; open-curve mask. |
| scrap | Scrap | Dry neutral plates; offset seam gradients; sparse rivet dots; asymmetric bolt mask. |
| tide | Tide | Blue-black base; low-amplitude radial caustic; pearl rim; tide curl mask. |
| velvet | Velvet | Plum-black base; two diagonal flock gradients; moonlit rim; tapered arch mask. |
| parchment | Parchment | Warm matte base; broad off-axis shade; 2% fibre microstripe; ledger-tab mask. |
| phosphor | Phosphor | Near-black base; static green scanline at ≤4%; restrained bloom; terminal bracket mask. |
| neon | Neon | Black lacquer base; one bright edge channel; static noise at ≤3%; broken signal mask. |
| glass | Glass | Opaque reading field; frosted outer gradient; thin edge highlight; split-bevel mask. |

## Font pairing do / do not

| Kit grouping | Do | Do not |
|---|---|---|
| High Elf / Dragon | Keep Cinzel/Cinzel Decorative to short display titles; use system serif/sans for dense UI. | Use decorative caps for rules, counts, or buttons. |
| Dwarf / Undead / Nocturne | Use MedievalSharp, Special Elite, Grenze Gotisch for occasional headings only. | Make them the default UI/body face. |
| Parchment / Wood / Merfolk | Let Libre Baskerville/Spectral carry prose with a neutral UI. | Reduce body contrast or line spacing for ‘mood’. |
| Dark Elf / Angelic / Infernal / Phoenix | Pair Cormorant, Crimson Pro, Playfair with simple controls. | Allow expressive serif to alter numeric alignment. |
| Circuit / Neon / Phosphor | Reserve Orbitron/mono display for labels that remain short. | Use monospaced display face for long narrative prose. |
| Goblin / Orc | Use display emphasis sparingly and a stable system body. | Encode severity or ownership via font personality. |

## Dice material FX — Excited roll mode (cosmetic only)

| Material group | Static read | Excited-roll cue | Reduced-motion / Kid Mode |
|---|---|---|---|
| Wood / bone / ivory / marble | Three visible facets, diffuse edge, high-legibility face | 120–180ms opacity highlight; soft tray shadow | Static highlight only |
| Brass / iron / scale / scrap | Faceted directional specular, controlled rim | One short opacity/transform settle, no shake | No movement; rim contrast step |
| Ember / sulfur / neon / circuit / phosphor | Dark body and one bounded bright channel | Single ≤250ms pulse, no repeat | Static luminance tier; no flash |
| Velvet / tide / iridescent / frost / holo | Material gradient and a readable face plane | One slow 150–220ms edge reveal | Static edge reveal |

The dice never change numerical result, timing, odds, loot, stats, or story outcome. No effect may be required to distinguish success/failure; use the normal semantic state system.

## References

[1]: https://support.discord.com/hc/en-us/articles/17162747936663-Shop-FAQ "Discord Shop FAQ — accessed 2026-08-19"
[2]: https://legal.epicgames.com/store/refund-policy "Epic Games Store Refund Policy — accessed 2026-08-19"
[3]: https://store.steampowered.com/steam_refunds/ "Steam Refunds — accessed 2026-08-19"
[4]: https://www.dndbeyond.com/posts/1003-how-to-customize-your-character-sheet-on-d-d "D&D Beyond customization article — accessed 2026-08-19"
[5]: https://blog.roll20.net/posts/introducing-the-new-roll20-dungeons-dragons-character-sheet/ "Roll20 sheet redesign — accessed 2026-08-19"
[6]: https://foundryvtt.com/packages/ "Foundry package directory — accessed 2026-08-19"
[7]: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum "W3C SC 1.4.3 — accessed 2026-08-19"
[8]: https://www.w3.org/WAI/WCAG21/Understanding/non-text-contrast.html "W3C SC 1.4.11 — accessed 2026-08-19"
[9]: https://www.w3.org/WAI/WCAG22/Understanding/use-of-color "W3C SC 1.4.1 — accessed 2026-08-19"
[10]: https://www.w3.org/WAI/WCAG22/Understanding/reflow "W3C SC 1.4.10 — accessed 2026-08-19"
[11]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion "MDN prefers-reduced-motion — accessed 2026-08-19"
[12]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/Properties/background-image "MDN background-image — accessed 2026-08-19"
[13]: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@font-face/font-display "MDN font-display — accessed 2026-08-19"
[14]: https://web.dev/articles/animations-guide "web.dev CSS animation guide — accessed 2026-08-19"
