# SynapticGM 29a Bundle Manifest

**Status:** Validated  
**Evidence boundary:** Only the supplied research brief was available; raw worst-cell transcripts and the referenced prior engineering draft were not supplied.

| ID | File | Bytes | SHA-256 |
|---|---|---:|---|
| COMPLETE | `SynapticGM_score_boost_post_28c_2026-08-27_COMPLETE.md` | 114246 | `b5df65ac1d2e0f65d0866854b2d0aaa05555a204154045ad85e319237b9d6ba0` |
| VALIDATION | `SynapticGM_score_boost_post_28c_2026-08-27_SCHEMA_FIXTURE_RESULTS.txt` | 117 | `22f625e6b790c1c12e9220e6dd77fb76745179395656b41484f0c34bb4e90af6` |
| SOURCE | `SynapticGM_score_boost_post_28c_2026-08-27_SOURCE_BRIEF.txt` | 5729 | `cc9e561e1e5f2d3b9bbaa6e4a396650628fe5c6d9410e30bfe21ae3adc236038` |
| SOURCE | `SynapticGM_score_boost_post_28c_2026-08-27_SOURCE_INVENTORY.md` | 3192 | `742992ab8bf7855260795ff9ddde9529bf5b824c1f664f30f96795b69c41e159` |
| T1 | `SynapticGM_score_boost_post_28c_2026-08-27_T01_executive_summary.md` | 7269 | `758d46f614660dde12e623eb9f5f937b0b3094e3b47844de3951762ff1cb6a96` |
| T2 | `SynapticGM_score_boost_post_28c_2026-08-27_T02_encounter_terminal_fsm.md` | 17602 | `d5ffe128d817cb1a63de18cc3a8f8d11d908fe925996c35b11bc896cdf18e063` |
| T2 | `SynapticGM_score_boost_post_28c_2026-08-27_T02_encounter_terminal_fsm.mmd` | 1421 | `f87e42876637935e65b0fceaae7cbf7875388437d903fefe4483969a22c83860` |
| T2 | `SynapticGM_score_boost_post_28c_2026-08-27_T02_encounter_terminal_fsm.png` | 173489 | `50586a93f87a8228fe3fa565cbe6238c02ffc1e3e46a11a71d14cbf10c606294` |
| T3 | `SynapticGM_score_boost_post_28c_2026-08-27_T03_entity_scrub_constitution.md` | 12720 | `b371454750b38c6a7ea74f8d9d0bc453f6cb8d7e4e0fac652b6d1fcfbe201703` |
| T4 | `SynapticGM_score_boost_post_28c_2026-08-27_T04_choice_compiler_edge_matrix.csv` | 3276 | `d3e2c320276d19f12bcbcff74fc811fb21baf6ced6e725e13a2aa0b4f08c960c` |
| T4 | `SynapticGM_score_boost_post_28c_2026-08-27_T04_choice_compiler_encounter_lock.md` | 9551 | `d39b4adb792f74aa20daffb1dc8c02f5ed7390089fc7b4d19c04903258730b21` |
| T5 | `SynapticGM_score_boost_post_28c_2026-08-27_T05_status_leak_firewall.md` | 9606 | `5315aa5358c70b3686343f9e28c54d4e225aa37ca3056dfc78f7f1b1b1cc911e` |
| T6 | `SynapticGM_score_boost_post_28c_2026-08-27_T06_topic_and_pyoa_branch_enforcement.md` | 12675 | `34c7402f9073c6a4b203f78d048abab73dd0b97896241b5395ccc5025de0bf97` |
| T7 | `SynapticGM_score_boost_post_28c_2026-08-27_T07_free_t12_hook_contract.md` | 10200 | `1da11de74a735373790560477a435d8814fd3ee40e916f6b2f9262f743c54bc1` |
| T8 | `SynapticGM_score_boost_post_28c_2026-08-27_T08_ranked_implementation_backlog.csv` | 8952 | `c362f8a678954fb3e8f2b40286d3b628ef27811d67346ab001a6772c892ea77f` |
| T8 | `SynapticGM_score_boost_post_28c_2026-08-27_T08_ranked_implementation_backlog.md` | 9513 | `f6fd7b821f61ad98537890ca63885056e8f9e233d53d327203f7983539cfecd7` |
| T9 | `SynapticGM_score_boost_post_28c_2026-08-27_T09_score_ceiling_model.md` | 7142 | `859f5602fc42543e5f2cd556cc5e5acfc5521400f02028cbad76db78ca75b036` |
| T10 | `SynapticGM_score_boost_post_28c_2026-08-27_T10_eval_harness_gates.schema.json` | 17268 | `7bc02bac9a618dd9284968fee0dac020d9b64535c3ef2ff960f51ddb897e117b` |
| T11 | `SynapticGM_score_boost_post_28c_2026-08-27_T11_unknowns_and_evidence_requests.md` | 8161 | `07a25e1e17bad3349d87444af4231eff641a325e185142fade1e7647c730483c` |
| T12 | `SynapticGM_score_boost_post_28c_2026-08-27_T12_what_not_to_do.md` | 6077 | `e7d69968ae87d5db16056469b7d2af165cee1b13fd26208814465651dbf3ae9d` |
| VALIDATION | `SynapticGM_score_boost_post_28c_2026-08-27_VALIDATION_REPORT.json` | 338 | `eafcf2b5a7e87766dc2b4a2c257969603ac335e39fd4d0572046585bca046349` |

The JSON manifest is authoritative. Manifest and checksum files are excluded from their own entry list to avoid recursive self-hashing.
