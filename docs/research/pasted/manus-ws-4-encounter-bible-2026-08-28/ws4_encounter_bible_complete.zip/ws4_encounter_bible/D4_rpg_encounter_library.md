# D4 — RPG Encounter Library

Eight **Cape District** templates resolve social and political pressure through named leverage, progress/danger clocks, irreversible concessions, and terminal withdrawal.

## Library Index

| ID | Template | Role | Max turns | Telegraph channels |
| --- | --- | --- | ---: | --- |
| `cape-district.social.dock-union-standoff` | Dock Union Standoff | social | 8 | npc, status |
| `cape-district.crisis.salt-clerk-betrayal` | The Salt Clerk’s Betrayal | crisis | 6 | scene, npc |
| `cape-district.crisis.flood-levy-deadline` | Flood Levy Deadline | crisis | 8 | status, faction |
| `cape-district.social.night-market-seizure` | Night Market Seizure | social | 7 | faction, scene |
| `cape-district.crisis.reef-medicine` | Reef Fever Allocation | crisis | 5 | item, npc |
| `cape-district.social.black-ledger-exposure` | Black Ledger Exposure | social | 7 | npc, status |
| `cape-district.social.harbor-master-leverage` | Harbormaster Leverage Negotiation | social | 5 | item, npc |
| `cape-district.ambush.silk-lane` | Silk Lane Political Ambush | ambush | 6 | scene, faction |

## 1. Dock Union Standoff

Union pickets block a bonded cargo while the Watch threatens dispersal.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **NPC:** The union steward demands wage escrow before the Watch bell’s sixth toll.<br>**STATUS:** Watch Intervention 2/6; at full, the square is cleared by force. |
| Stakes | Secure passage without sacrificing workers or let the Watch define the outcome.<br>**Spend the payroll ledger to prove withheld wages** — The employer funds escrow and the union releases the cargo.<br>**Call Sister Merrow as neutral arbiter** — A bonded settlement releases cargo and defers final wages.<br>**Walk away and concede the night shipment** — The standoff ends; the Watch seizes the shipment and the player preserves the ledger. |
| Resolution | `clock`; maximum 8 turns. **Forced terminal:** The Watch disperses the square, seizes cargo, and arrests pickets; the confrontation ends. |
| Aftermath | Minimum 2 receipt types; supported: faction, loot, npc, quest. |
| Biome and window | cape-district-harbor; eligible turns 5–50; cooldown 15. |


**Prose example.**

> **Telegraph:** The steward names wage escrow and the sixth bell while the intervention clock reveals the Watch’s exact fallback.
>
> **Stakes:** Spend the one-use payroll ledger, call a neutral arbiter whose credibility can be spent, or leave and concede the shipment.
>
> **Resolution:** Every argument consumes leverage or advances a clock; at eight turns the Watch action commits and the scene cannot pad.
>
> **Aftermath:** The receipt records cargo custody, union/Watch standing, NPC arrests or settlement, and the next quest.

## 2. The Salt Clerk’s Betrayal

A trusted clerk sells the player’s route list to customs and asks for protection.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The route list bears fresh customs pinholes and the clerk’s ink is missing.<br>**NPC:** The clerk asks for passage on the dawn packet in exchange for naming the buyer. |
| Stakes | Extract the buyer’s name, turn the clerk over, or protect them and absorb the political cost.<br>**Spend the matched ink proof to force a confession** — The clerk names the buyer and accepts protective custody.<br>**Grant passage on the dawn packet** — Protection buys the name and keeps the clerk alive.<br>**Walk away and let customs take the clerk** — The confrontation ends; the clerk enters customs custody and the buyer remains hidden. |
| Resolution | `clock`; maximum 6 turns. **Forced terminal:** Customs takes the clerk and the immediate confession opportunity closes. |
| Aftermath | Minimum 2 receipt types; supported: faction, loot, npc, quest. |
| Biome and window | cape-district-harbor; eligible turns 8–70; cooldown 20. |


**Prose example.**

> **Telegraph:** Pinholes and missing ink prove the route list was copied, while the clerk names the dawn-packet price.
>
> **Stakes:** Spend the ink match, spend a unique packet seat, or leave the clerk to customs custody.
>
> **Resolution:** Proof and passage cannot be reused; customs arrives by turn six and converts the unresolved crisis into a prison-barge hook.
>
> **Aftermath:** The system records confession, buyer intel, custody, passage asset, faction standing, and the appropriate follow-up.

## 3. Flood Levy Deadline

The council will condemn one ward unless the player assembles funding or proves fraud.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **STATUS:** Levy Vote 3/6; at full, Low Cape is condemned.<br>**FACTION:** Merchant Council will fund two segments in exchange for warehouse immunity. |
| Stakes | Save Low Cape without granting permanent immunity, or choose which cost the district carries.<br>**Spend the verified drainage audit to expose fraud** — The fraud finding voids the condemnation vote.<br>**Trade warehouse immunity for emergency funding** — Funding saves the ward while merchants gain declared immunity.<br>**Walk away and evacuate Low Cape** — The vote proceeds; the player pivots to evacuation rather than repeating debate. |
| Resolution | `clock`; maximum 8 turns. **Forced terminal:** The vote condemns Low Cape and the crisis ends in an evacuation arc. |
| Aftermath | Minimum 2 receipt types; supported: faction, loot, npc, quest. |
| Biome and window | cape-district-civic; eligible turns 10–90; cooldown 30. |


**Prose example.**

> **Telegraph:** The vote clock states the condemnation result, and the merchants’ immunity price appears as a named political cost.
>
> **Stakes:** Spend the audit, trade immunity for funding, or abandon debate and begin evacuation.
>
> **Resolution:** Every maneuver moves defense or vote clocks; turn eight condemns the ward and opens a different objective.
>
> **Aftermath:** Receipts preserve ward status, residents, council/merchant standing, access, audit consumption, and evacuation or fraud quests.

## 4. Night Market Seizure

The Watch moves to confiscate unlicensed stalls while two factions claim authority.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **FACTION:** A posted order lists confiscation at moonrise and names the officer authorized to suspend it.<br>**SCENE:** Stallkeepers chain carts into three defensible lanes. |
| Stakes | Keep the market open, evacuate it intact, or let confiscation redefine district control.<br>**Spend the harbor jurisdiction writ** — The Watch suspends seizure under superior harbor authority.<br>**Organize a three-lane stall evacuation** — The goods escape before the Watch can seize them.<br>**Walk away and concede the market** — The Watch takes the market and the current confrontation ends. |
| Resolution | `clock`; maximum 7 turns. **Forced terminal:** Moonrise confiscation completes and the encounter becomes a recovery arc. |
| Aftermath | Minimum 2 receipt types; supported: faction, loot, npc, quest. |
| Biome and window | cape-district-market; eligible turns 8–75; cooldown 18. |


**Prose example.**

> **Telegraph:** The seizure order names moonrise and Lieutenant Vale, while chained stalls reveal the three-lane evacuation plan.
>
> **Stakes:** Spend the writ, evacuate changing lanes, or concede control and end the standoff immediately.
>
> **Resolution:** The writ is one-use and evacuation failures close lanes; the seventh turn commits confiscation and a recovery quest.
>
> **Aftermath:** The ledger records market control, goods, Watch and stallkeeper standing, network access, and recovery or charter hooks.

## 5. Reef Fever Allocation

A limited antitoxin shipment can protect dockworkers or reef refugees, not both.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **ITEM:** The crate holds twelve sealed doses; both clinics require nine before dawn.<br>**NPC:** Both physicians state the mortality and political consequences of receiving only three doses. |
| Stakes | Allocate scarce medicine with no hidden option to save everyone.<br>**Spend the cargo manifest to requisition three reserve doses** — Three reserve doses become available at the cost of one turn.<br>**Split six doses to each clinic** — Both clinics receive partial protection and both suffer declared losses.<br>**Walk away and let the health board choose** — The board allocates by policy and the player loses control of the decision. |
| Resolution | `clock`; maximum 5 turns. **Forced terminal:** Dawn arrives without allocation; both clinics suffer and containment begins. |
| Aftermath | Minimum 2 receipt types; supported: faction, loot, npc, quest. |
| Biome and window | cape-district-clinics; eligible turns 12–85; cooldown 30. |


**Prose example.**

> **Telegraph:** The visible dose count and physicians’ estimates establish that no hidden perfect allocation exists.
>
> **Stakes:** Use the one-use manifest to seek reserves, split the crate with known losses, or surrender the choice to the board.
>
> **Resolution:** Inventory cannot duplicate; dawn advances with attempts and the fifth turn converts delay into containment.
>
> **Aftermath:** The receipt stores exact clinic coverage, casualties, dose inventory, customs/board standing, favors, and recovery hooks.

## 6. Black Ledger Exposure

A journalist will publish a ledger that implicates both enemies and allies unless the player shapes the release.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **NPC:** Editor Saye names the print deadline and the three redactions she will accept.<br>**STATUS:** Press Run 2/6; at full, the unredacted ledger becomes public. |
| Stakes | Publish truth, protect vulnerable sources, or suppress the ledger at a lasting trust cost.<br>**Spend the verified source chain to require safe redactions** — The ledger publishes with the agreed source protections.<br>**Trade an exclusive interview for named redactions** — The interview purchases limited, visible redactions.<br>**Walk away and accept unredacted publication** — The confrontation ends and every named actor faces the declared fallout. |
| Resolution | `clock`; maximum 7 turns. **Forced terminal:** The presses complete and the exposure crisis ends with source-protection work. |
| Aftermath | Minimum 2 receipt types; supported: faction, loot, npc, quest. |
| Biome and window | cape-district-press-row; eligible turns 10–80; cooldown 22. |


**Prose example.**

> **Telegraph:** Editor Saye names the print deadline and acceptable redactions while the press clock shows when publication becomes irreversible.
>
> **Stakes:** Spend the source chain, trade a one-use exclusive, or leave and accept unredacted fallout.
>
> **Resolution:** Leverage is consumed or rejected; at seven turns publication commits and the debate cannot recur.
>
> **Aftermath:** The outcome stores publication form, source safety, press/reform standing, editor relationship, intel, and follow-ups.

## 7. Harbormaster Leverage Negotiation

The Harbormaster controls a quarantine berth and will trade access for silence or verified public cover.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **ITEM:** A blue-wax permit links the Harbormaster’s clerk to an illegal berth sale.<br>**NPC:** The Harbormaster offers one berth in exchange for the permit before the tide turns. |
| Stakes | Secure quarantine access without creating an infinitely reusable threat.<br>**Spend the blue-wax permit to demand berth access** — The evidence compels one berth authorization.<br>**Trade silence for a one-voyage berth** — A binding silence promise buys one voyage.<br>**Walk away and miss the tide window** — The tide window closes and the player must pursue another route. |
| Resolution | `clock`; maximum 5 turns. **Forced terminal:** The tide turns, ending this negotiation and opening the reef anchorage route. |
| Aftermath | Minimum 2 receipt types; supported: faction, loot, npc, quest. |
| Biome and window | cape-district-harbor; eligible turns 4–60; cooldown 15. |


**Prose example.**

> **Telegraph:** The blue-wax permit proves the berth sale and Oren names the exact silence-for-access trade before the tide turns.
>
> **Stakes:** Consume the permit, bind a one-voyage silence promise, or leave and lose this tide window.
>
> **Resolution:** Every leverage item becomes consumed, bound, or discredited; turn five closes the berth and creates a new route.
>
> **Aftermath:** The receipt stores berth scope, permit/promise state, Oren and Harbor Office reactions, and the follow-up route.

## 8. Silk Lane Political Ambush

A knife crew stages an attack to make the player appear responsible for faction violence.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** Shop shutters close in sequence and a dropped campaign ribbon points against the wind.<br>**FACTION:** A courier warns that three pamphleteers are waiting to report the first blade drawn. |
| Stakes | Survive without validating the attackers’ public narrative.<br>**Expose the planted campaign ribbon to the witnesses** — The witnesses recognize the frame-up and the crew withdraws.<br>**Turn the pamphleteers by protecting them from the first volley** — Protected witnesses identify the attackers and break the frame.<br>**Escape through the dye yard and accept suspicion** — The player escapes alive, but the attackers control the first public account. |
| Resolution | `clock`; maximum 6 turns. **Forced terminal:** The false account reaches print, the attackers escape, and the scene ends in a name-clearing arc. |
| Aftermath | Minimum 2 receipt types; supported: faction, loot, npc, quest. |
| Biome and window | cape-district-market; eligible turns 9–85; cooldown 25. |


**Prose example.**

> **Telegraph:** Closing shutters, an impossible ribbon, and waiting pamphleteers reveal that the ambush targets reputation as much as life.
>
> **Stakes:** Spend the ribbon proof, protect witnesses through changing cover, or flee and accept suspicion.
>
> **Resolution:** Witness and blame clocks advance; by turn six the account prints and the confrontation ends in a clear-your-name quest.
>
> **Aftermath:** The system records witness states, attacker identity, public opinion, escape location, intel, and the next political beat.
