# D5 — PYOA Crisis Library

Four PYOA bibles contain six crises each. Every fork writes an exclusive fact, locks the opposing fact, schedules a delayed callback, changes ending eligibility, and converges without deleting branch state.

## Library Index

| ID | Template | Role | Max turns | Telegraph channels |
| --- | --- | --- | ---: | --- |
| `thornferry.crisis.millstone-charter` | Millstone Charter | crisis | 3 | item |
| `thornferry.crisis.trust-the-miller` | Trust the Miller | crisis | 3 | scene |
| `thornferry.crisis.bandits-or-villagers` | Bandits or Villagers | crisis | 3 | scene |
| `thornferry.crisis.floodgate-sacrifice` | Floodgate Sacrifice | crisis | 3 | scene |
| `thornferry.crisis.bell-of-witness` | Bell of Witness | crisis | 3 | scene |
| `thornferry.crisis.ferrymans-ending` | Ferryman’s Ending | crisis | 3 | scene |
| `vesper-glass.crisis.mirror-census` | Mirror Census | crisis | 3 | scene |
| `vesper-glass.crisis.smugglers-reflection` | Smuggler’s Reflection | crisis | 3 | scene |
| `vesper-glass.crisis.broken-opera-pact` | Broken Opera Pact | crisis | 3 | scene |
| `vesper-glass.crisis.name-in-glass` | Name in Glass | crisis | 3 | scene |
| `vesper-glass.crisis.lantern-heir` | Lantern Heir | crisis | 3 | scene |
| `vesper-glass.crisis.city-without-faces` | City Without Faces | crisis | 3 | scene |
| `erebus-9.crisis.oxygen-compact` | Oxygen Compact | crisis | 3 | scene |
| `erebus-9.crisis.wake-the-navigator` | Wake the Navigator | crisis | 3 | scene |
| `erebus-9.crisis.quarantine-breach` | Quarantine Breach | crisis | 3 | scene |
| `erebus-9.crisis.reactor-vote` | Reactor Vote | crisis | 3 | scene |
| `erebus-9.crisis.signal-from-deck-nine` | Signal from Deck Nine | crisis | 3 | scene |
| `erebus-9.crisis.last-shuttle` | Last Shuttle | crisis | 3 | scene |
| `ashwinter-court.crisis.white-hart-oath` | White Hart Oath | crisis | 3 | scene |
| `ashwinter-court.crisis.warmth-tax` | Warmth Tax | crisis | 3 | scene |
| `ashwinter-court.crisis.heir-beneath-ice` | Heir Beneath Ice | crisis | 3 | scene |
| `ashwinter-court.crisis.mask-at-midwinter` | Mask at Midwinter | crisis | 3 | scene |
| `ashwinter-court.crisis.thaw-the-prisoner` | Thaw the Prisoner | crisis | 3 | scene |
| `ashwinter-court.crisis.crown-of-embers` | Crown of Embers | crisis | 3 | scene |

## 1. Millstone Charter

Choose who holds the only charter proving the millers’ water rights.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **ITEM:** Keeping the charter preserves public arbitration; surrendering it buys village amnesty and destroys the original. |
| Stakes | Choose law or immediate safety before the Baron’s clerk seals the levy.<br>**Keep the Millstone Charter** — The player keeps the evidence, angers the Baron, and qualifies for the free-mills ending.<br>**Surrender the Charter for Amnesty** — The village gains amnesty, the Baron controls the evidence, and arbitration closes. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay lets the clerk seize the charter; the story continues without original evidence. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | thornferry-mill; eligible turns 4–35; cooldown 9999. |


**Prose example.**

> **Telegraph:** The clerk states that surrender buys amnesty while the item panel warns it destroys public arbitration.
>
> **Stakes:** Keep the charter for a later hearing or surrender it for immediate amnesty; the flags are mutually exclusive.
>
> **Resolution:** The selected option atomically writes the holder fact, locks its opposite, schedules the hearing callback, and sets ending eligibility.
>
> **Aftermath:** The receipt records charter custody, Miller and faction reactions, the delayed hearing variant, and the eligible ending.

## 2. Trust the Miller

Choose whether Tarrow controls the grain tally during the flood shortage.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** Tarrow offers his sealed tally while the cooper warns that one page was replaced. |
| Stakes | Trust buys speed; doubt preserves oversight but delays relief.<br>**Trust Tarrow with the Tally** — Trust Tarrow with the Tally writes a durable fact and qualifies ending.millers-mandate.<br>**Demand a Public Audit** — Demand a Public Audit writes the opposing fact and qualifies ending.open-granary. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits tally-seized-by-bailiff; the crisis ends and schedules shortage.bailiff-count. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | thornferry-mill; eligible turns 6–40; cooldown 9999. |


**Prose example.**

> **Telegraph:** Tarrow offers his sealed tally while the cooper warns that one page was replaced.
>
> **Stakes:** Trust Tarrow with the Tally or Demand a Public Audit; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at thornferry-flood-season, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-2-grain-shortage, and ending eligibility.

## 3. Bandits or Villagers

Decide which group receives the only safe ferry crossing before soldiers arrive.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** Two boats remain: one carries wounded villagers, the other repentant bandits with medicine. |
| Stakes | Choose immediate lives, future medicine, and who is left to the soldiers.<br>**Ferry the Villagers First** — Ferry the Villagers First writes a durable fact and qualifies ending.village-kept.<br>**Ferry the Bandits and Medicine** — Ferry the Bandits and Medicine writes the opposing fact and qualifies ending.mercy-road. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits both-boats-confiscated; the crisis ends and schedules soldiers.ferry-seized. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | thornferry-river; eligible turns 10–55; cooldown 9999. |


**Prose example.**

> **Telegraph:** Two boats remain: one carries wounded villagers, the other repentant bandits with medicine.
>
> **Stakes:** Ferry the Villagers First or Ferry the Bandits and Medicine; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at thornferry-east-bank, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-3-soldier-arrival, and ending eligibility.

## 4. Floodgate Sacrifice

Choose which district the emergency floodgate protects.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The gate wheel can lock toward Mill Row or Reedbank only once before the axle shears. |
| Stakes | Protect production or homes, with no hidden third position.<br>**Turn the Gate toward Mill Row** — Turn the Gate toward Mill Row writes a durable fact and qualifies ending.granary-standing.<br>**Turn the Gate toward Reedbank** — Turn the Gate toward Reedbank writes the opposing fact and qualifies ending.homes-before-grain. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits gate-axle-breaks-centered; the crisis ends and schedules flood.both-damaged. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | thornferry-floodgate; eligible turns 14–65; cooldown 9999. |


**Prose example.**

> **Telegraph:** The gate wheel can lock toward Mill Row or Reedbank only once before the axle shears.
>
> **Stakes:** Turn the Gate toward Mill Row or Turn the Gate toward Reedbank; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at thornferry-high-ground, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-4-flood-impact, and ending eligibility.

## 5. Bell of Witness

Choose whether to ring a bell that summons testimony and invading authority alike.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The witness bell carries to the county fort; ringing exposes the Baron and invites occupation. |
| Stakes | Choose public proof or local secrecy.<br>**Ring the Bell of Witness** — Ring the Bell of Witness writes a durable fact and qualifies ending.barony-overturned.<br>**Muffle the Bell** — Muffle the Bell writes the opposing fact and qualifies ending.thornferry-autonomy. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits bell-rings-in-storm; the crisis ends and schedules trial.uncontrolled-summons. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | thornferry-bell-tower; eligible turns 18–75; cooldown 9999. |


**Prose example.**

> **Telegraph:** The witness bell carries to the county fort; ringing exposes the Baron and invites occupation.
>
> **Stakes:** Ring the Bell of Witness or Muffle the Bell; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at thornferry-court-day, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-5-charter-trial, and ending eligibility.

## 6. Ferryman’s Ending

Choose the final custody of the ferry and its toll charter.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** At dawn the old ferryman offers the oar to the village or to the player; accepting either closes the other succession. |
| Stakes | Choose stewardship or personal rule.<br>**Give the Oar to the Village** — Give the Oar to the Village writes a durable fact and qualifies ending.common-ferry.<br>**Take the Ferryman’s Oar** — Take the Ferryman’s Oar writes the opposing fact and qualifies ending.new-ferryman. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits barony-claims-ferry; the crisis ends and schedules epilogue.baronial-tolls. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | thornferry-ferry; eligible turns 22–95; cooldown 9999. |


**Prose example.**

> **Telegraph:** At dawn the old ferryman offers the oar to the village or to the player; accepting either closes the other succession.
>
> **Stakes:** Give the Oar to the Village or Take the Ferryman’s Oar; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at thornferry-epilogue, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback epilogue-river-crossing, and ending eligibility.

## 7. Mirror Census

Choose whether citizens must register reflections to prove identity.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The census mirror can reveal impostors but permanently archives every registered face. |
| Stakes | Choose security through registration or privacy through refusal.<br>**Open the Mirror Census** — Open the Mirror Census writes a durable fact and qualifies ending.city-accounted.<br>**Shatter the Census Seal** — Shatter the Census Seal writes the opposing fact and qualifies ending.unmeasured-city. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits census-seal-self-activates; the crisis ends and schedules masquerade.corrupt-census. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | vesper-glass-census-hall; eligible turns 4–35; cooldown 9999. |


**Prose example.**

> **Telegraph:** The census mirror can reveal impostors but permanently archives every registered face.
>
> **Stakes:** Open the Mirror Census or Shatter the Census Seal; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at vesper-glass-equinox, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-2-masquerade, and ending eligibility.

## 8. Smuggler’s Reflection

Choose whether to shelter a reflection detached from its smuggler owner.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The loose reflection knows the canal route; returning it restores one criminal, while sheltering it creates a new person. |
| Stakes | Choose restoration or emancipation.<br>**Return the Smuggler’s Reflection** — Return the Smuggler’s Reflection writes a durable fact and qualifies ending.debt-paid.<br>**Grant the Reflection a Name** — Grant the Reflection a Name writes the opposing fact and qualifies ending.second-self. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits reflection-fades-unnamed; the crisis ends and schedules canal.lost-route. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | vesper-glass-canals; eligible turns 7–45; cooldown 9999. |


**Prose example.**

> **Telegraph:** The loose reflection knows the canal route; returning it restores one criminal, while sheltering it creates a new person.
>
> **Stakes:** Return the Smuggler’s Reflection or Grant the Reflection a Name; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at vesper-glass-canal-hub, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-3-canal-crossing, and ending eligibility.

## 9. Broken Opera Pact

Choose which singer carries a lethal note needed to finish the opera ward.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** Only one throat can hold the final glass note; the lead demands it, while the understudy offers consent. |
| Stakes | Choose fame-bound duty or voluntary sacrifice.<br>**Bind the Note to the Lead** — Bind the Note to the Lead writes a durable fact and qualifies ending.perfect-opera.<br>**Accept the Understudy’s Offer** — Accept the Understudy’s Offer writes the opposing fact and qualifies ending.consent-in-glass. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits note-binds-random-singer; the crisis ends and schedules opera.chaotic-aria. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | vesper-glass-opera; eligible turns 10–60; cooldown 9999. |


**Prose example.**

> **Telegraph:** Only one throat can hold the final glass note; the lead demands it, while the understudy offers consent.
>
> **Stakes:** Bind the Note to the Lead or Accept the Understudy’s Offer; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at vesper-glass-opera-night, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-4-final-aria, and ending eligibility.

## 10. Name in Glass

Choose whether to reveal a true name etched beneath the city mirror.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** Speaking the etched name frees its owner and also lets every listener command them once. |
| Stakes | Choose exposure or concealment.<br>**Speak the Name Publicly** — Speak the Name Publicly writes a durable fact and qualifies ending.named-and-free.<br>**Silver Over the Name** — Silver Over the Name writes the opposing fact and qualifies ending.protected-silence. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits name-reflects-by-itself; the crisis ends and schedules trial.uncontrolled-name. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | vesper-glass-under-mirror; eligible turns 13–70; cooldown 9999. |


**Prose example.**

> **Telegraph:** Speaking the etched name frees its owner and also lets every listener command them once.
>
> **Stakes:** Speak the Name Publicly or Silver Over the Name; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at vesper-glass-trial, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-5-mirror-trial, and ending eligibility.

## 11. Lantern Heir

Choose which claimant receives the lantern that reveals inherited memories.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The lantern authenticates blood and transfers every prior heir’s grief to its bearer. |
| Stakes | Choose lawful succession or a chosen heir.<br>**Give the Lantern to the Blood Heir** — Give the Lantern to the Blood Heir writes a durable fact and qualifies ending.old-line-restored.<br>**Give the Lantern to the Chosen Heir** — Give the Lantern to the Chosen Heir writes the opposing fact and qualifies ending.new-light. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits lantern-chooses-child; the crisis ends and schedules equinox.unknown-heir. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | vesper-glass-lantern-court; eligible turns 16–82; cooldown 9999. |


**Prose example.**

> **Telegraph:** The lantern authenticates blood and transfers every prior heir’s grief to its bearer.
>
> **Stakes:** Give the Lantern to the Blood Heir or Give the Lantern to the Chosen Heir; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at vesper-glass-equinox, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-6-equinox, and ending eligibility.

## 12. City Without Faces

Choose whether the city keeps its faces after the mirror plague.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The cure restores every face and every suppressed crime; the veil ends the plague by making anonymity permanent. |
| Stakes | Choose memory with accountability or safety without faces.<br>**Release the Restoring Light** — Release the Restoring Light writes a durable fact and qualifies ending.faces-and-reckoning.<br>**Accept Permanent Veils** — Accept Permanent Veils writes the opposing fact and qualifies ending.city-without-faces. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits plague-erases-faces; the crisis ends and schedules epilogue.forced-anonymity. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | vesper-glass-central-mirror; eligible turns 20–95; cooldown 9999. |


**Prose example.**

> **Telegraph:** The cure restores every face and every suppressed crime; the veil ends the plague by making anonymity permanent.
>
> **Stakes:** Release the Restoring Light or Accept Permanent Veils; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at vesper-glass-epilogue, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback epilogue-first-dawn, and ending eligibility.

## 13. Oxygen Compact

Choose which deck receives the station’s last stable oxygen reserve.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** Life support can stabilize Habitation or Hydroponics, not both, before the next orbit. |
| Stakes | Choose immediate population survival or future food security.<br>**Route Oxygen to Habitation** — Route Oxygen to Habitation writes a durable fact and qualifies ending.people-first.<br>**Route Oxygen to Hydroponics** — Route Oxygen to Hydroponics writes the opposing fact and qualifies ending-seed-ark. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits oxygen-splits-inefficiently; the crisis ends and schedules orbit.both-critical. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | erebus-9-life-support; eligible turns 4–35; cooldown 9999. |


**Prose example.**

> **Telegraph:** Life support can stabilize Habitation or Hydroponics, not both, before the next orbit.
>
> **Stakes:** Route Oxygen to Habitation or Route Oxygen to Hydroponics; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at erebus-9-central-ring, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-2-next-orbit, and ending eligibility.

## 14. Wake the Navigator

Choose whether to wake a cryogenic navigator whose neural map will decay on use.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** Waking Ilyan gives one perfect route and destroys the backup memory; leaving him asleep forces a risky manual burn. |
| Stakes | Choose certainty now or preserve the navigator.<br>**Wake Navigator Ilyan** — Wake Navigator Ilyan writes a durable fact and qualifies ending-guided-home.<br>**Attempt the Manual Burn** — Attempt the Manual Burn writes the opposing fact and qualifies ending-crew-found-path. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits navigator-wakes-damaged; the crisis ends and schedules burn.fragmented-route. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | erebus-9-cryo; eligible turns 7–45; cooldown 9999. |


**Prose example.**

> **Telegraph:** Waking Ilyan gives one perfect route and destroys the backup memory; leaving him asleep forces a risky manual burn.
>
> **Stakes:** Wake Navigator Ilyan or Attempt the Manual Burn; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at erebus-9-transit, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-3-orbital-burn, and ending eligibility.

## 15. Quarantine Breach

Choose whether to vent an infected deck or open it for rescue.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The breach door can vent the spores or admit a rescue team once; either action locks the other. |
| Stakes | Choose containment or rescue.<br>**Vent Quarantine Deck** — Vent Quarantine Deck writes a durable fact and qualifies ending-clean-station.<br>**Open for Rescue** — Open for Rescue writes the opposing fact and qualifies ending-no-one-left. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits breach-spreads-uncontrolled; the crisis ends and schedules medbay.station-exposure. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | erebus-9-quarantine; eligible turns 10–60; cooldown 9999. |


**Prose example.**

> **Telegraph:** The breach door can vent the spores or admit a rescue team once; either action locks the other.
>
> **Stakes:** Vent Quarantine Deck or Open for Rescue; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at erebus-9-medbay, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-4-medbay-outcome, and ending eligibility.

## 16. Reactor Vote

Choose whether to overload the reactor for propulsion or preserve it for station life.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The reactor has one safe cycle left; propulsion reaches rescue, while station mode supports a long siege. |
| Stakes | Choose escape or endurance.<br>**Burn the Reactor for Thrust** — Burn the Reactor for Thrust writes a durable fact and qualifies ending-last-burn.<br>**Preserve the Reactor for Station Life** — Preserve the Reactor for Station Life writes the opposing fact and qualifies ending-station-keepers. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits reactor-scrams; the crisis ends and schedules siege-no-thrust. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | erebus-9-reactor; eligible turns 13–72; cooldown 9999. |


**Prose example.**

> **Telegraph:** The reactor has one safe cycle left; propulsion reaches rescue, while station mode supports a long siege.
>
> **Stakes:** Burn the Reactor for Thrust or Preserve the Reactor for Station Life; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at erebus-9-command-vote, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-5-rescue-window, and ending eligibility.

## 17. Signal from Deck Nine

Choose whether to answer a signal using the dead captain’s voice.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The signal offers docking coordinates but repeats a private phrase only the captain knew. |
| Stakes | Choose contact or radio silence.<br>**Answer the Deck Nine Signal** — Answer the Deck Nine Signal writes a durable fact and qualifies ending-voice-in-hull.<br>**Maintain Radio Silence** — Maintain Radio Silence writes the opposing fact and qualifies ending-unanswered-orbit. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits signal-locks-on; the crisis ends and schedules docking-forced-contact. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | erebus-9-comms; eligible turns 16–82; cooldown 9999. |


**Prose example.**

> **Telegraph:** The signal offers docking coordinates but repeats a private phrase only the captain knew.
>
> **Stakes:** Answer the Deck Nine Signal or Maintain Radio Silence; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at erebus-9-docking-spine, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-6-docking, and ending eligibility.

## 18. Last Shuttle

Choose who receives the last shuttle seats before station breakup.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The shuttle seats the bridge crew or the habitation delegates, and launch seals the other group aboard. |
| Stakes | Choose command continuity or civilian mandate.<br>**Seat the Bridge Crew** — Seat the Bridge Crew writes a durable fact and qualifies ending-command-seed.<br>**Seat the Habitation Delegates** — Seat the Habitation Delegates writes the opposing fact and qualifies ending-civic-seed. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits shuttle-launches-autonomously; the crisis ends and schedules epilogue-random-survivors. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | erebus-9-hangar; eligible turns 20–95; cooldown 9999. |


**Prose example.**

> **Telegraph:** The shuttle seats the bridge crew or the habitation delegates, and launch seals the other group aboard.
>
> **Stakes:** Seat the Bridge Crew or Seat the Habitation Delegates; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at erebus-9-breakup, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback epilogue-colony, and ending eligibility.

## 19. White Hart Oath

Choose whether to swear the winter hunt to Crown or forest spirits.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The Hart accepts one oath; Crown grants law, while the spirits grant passage through the whitewood. |
| Stakes | Choose royal duty or old covenant.<br>**Swear the Hunt to the Crown** — Swear the Hunt to the Crown writes a durable fact and qualifies ending-crowned-hunter.<br>**Swear the Hunt to the Spirits** — Swear the Hunt to the Spirits writes the opposing fact and qualifies ending-keeper-of-whitewood. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits hart-refuses-oath; the crisis ends and schedules hunt.no-guide. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | ashwinter-whitewood; eligible turns 4–35; cooldown 9999. |


**Prose example.**

> **Telegraph:** The Hart accepts one oath; Crown grants law, while the spirits grant passage through the whitewood.
>
> **Stakes:** Swear the Hunt to the Crown or Swear the Hunt to the Spirits; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at ashwinter-whitewood, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-2-winter-hunt, and ending eligibility.

## 20. Warmth Tax

Choose whether palace heat is rationed to villages or preserved for the court.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The ember tithe can warm three villages or keep the palace defenses alive through midwinter. |
| Stakes | Choose subjects or stronghold.<br>**Send the Ember Tithe to the Villages** — Send the Ember Tithe to the Villages writes a durable fact and qualifies ending-hearth-queen.<br>**Keep the Ember Tithe at Court** — Keep the Ember Tithe at Court writes the opposing fact and qualifies ending-last-stronghold. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits embers-divided-too-late; the crisis ends and schedules midwinter-both-cold. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | ashwinter-ember-hall; eligible turns 7–45; cooldown 9999. |


**Prose example.**

> **Telegraph:** The ember tithe can warm three villages or keep the palace defenses alive through midwinter.
>
> **Stakes:** Send the Ember Tithe to the Villages or Keep the Ember Tithe at Court; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at ashwinter-midwinter, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-3-midwinter, and ending eligibility.

## 21. Heir Beneath Ice

Choose whether to thaw the lost heir or preserve the treaty built on their death.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The heir lives beneath the lake; waking them voids the regent’s peace treaty. |
| Stakes | Choose rightful return or political stability.<br>**Thaw the Lost Heir** — Thaw the Lost Heir writes a durable fact and qualifies ending-rightful-thaw.<br>**Leave the Heir Beneath Ice** — Leave the Heir Beneath Ice writes the opposing fact and qualifies ending-peace-kept. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits ice-cracks-without-ritual; the crisis ends and schedules court-heir-damaged. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | ashwinter-frozen-lake; eligible turns 10–60; cooldown 9999. |


**Prose example.**

> **Telegraph:** The heir lives beneath the lake; waking them voids the regent’s peace treaty.
>
> **Stakes:** Thaw the Lost Heir or Leave the Heir Beneath Ice; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at ashwinter-frozen-lake, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-4-court-claim, and ending eligibility.

## 22. Mask at Midwinter

Choose which identity to wear before the court’s truth-seeing candles.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The rebel mask protects allies but condemns the wearer; the royal mask preserves rank and exposes the rebels. |
| Stakes | Choose solidarity or privilege.<br>**Wear the Rebel Mask** — Wear the Rebel Mask writes a durable fact and qualifies ending-red-mask-rising.<br>**Wear the Royal Mask** — Wear the Royal Mask writes the opposing fact and qualifies ending-winter-favorite. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits candles-name-player; the crisis ends and schedules ball-identity-exposed. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | ashwinter-palace; eligible turns 13–72; cooldown 9999. |


**Prose example.**

> **Telegraph:** The rebel mask protects allies but condemns the wearer; the royal mask preserves rank and exposes the rebels.
>
> **Stakes:** Wear the Rebel Mask or Wear the Royal Mask; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at ashwinter-midwinter-ball, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-5-mask-ball, and ending eligibility.

## 23. Thaw the Prisoner

Choose whether to release an enemy general who knows how to stop the endless winter.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The prisoner offers the thaw rite; freedom risks renewed war, while execution preserves war but loses the rite. |
| Stakes | Choose dangerous knowledge or final punishment.<br>**Release the Frost General** — Release the Frost General writes a durable fact and qualifies ending-enemy-sun.<br>**Execute the Frost General** — Execute the Frost General writes the opposing fact and qualifies ending-winter-justice. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits prisoner-dies-unheard; the crisis ends and schedules thaw-fragmented-rite. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | ashwinter-ice-prison; eligible turns 16–82; cooldown 9999. |


**Prose example.**

> **Telegraph:** The prisoner offers the thaw rite; freedom risks renewed war, while execution preserves war but loses the rite.
>
> **Stakes:** Release the Frost General or Execute the Frost General; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at ashwinter-prison, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback chapter-6-thaw-rite, and ending eligibility.

## 24. Crown of Embers

Choose who bears the crown that can end winter by consuming its wearer.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The crown ends winter but burns one sovereign from history; giving it away changes whose name survives. |
| Stakes | Choose self-sacrifice or appointed sacrifice.<br>**Wear the Crown of Embers** — Wear the Crown of Embers writes a durable fact and qualifies ending-sun-without-name.<br>**Give the Crown to Queen Syr** — Give the Crown to Queen Syr writes the opposing fact and qualifies ending-last-queen. |
| Resolution | `fork`; maximum 3 turns. **Forced terminal:** Delay commits crown-burns-unclaimed; the crisis ends and schedules epilogue-winter-continues. |
| Aftermath | Minimum 3 receipt types; supported: faction, npc, quest. |
| Biome and window | ashwinter-throne; eligible turns 20–95; cooldown 9999. |


**Prose example.**

> **Telegraph:** The crown ends winter but burns one sovereign from history; giving it away changes whose name survives.
>
> **Stakes:** Wear the Crown of Embers or Give the Crown to Queen Syr; each writes an exclusive fact, a delayed callback, and distinct ending eligibility.
>
> **Resolution:** The choice commits once within three turns. Both paths converge at ashwinter-epilogue, which reads rather than erases the stored flags.
>
> **Aftermath:** The receipt records the selected fact, the locked opposite, faction and NPC changes, callback epilogue-first-thaw, and ending eligibility.
