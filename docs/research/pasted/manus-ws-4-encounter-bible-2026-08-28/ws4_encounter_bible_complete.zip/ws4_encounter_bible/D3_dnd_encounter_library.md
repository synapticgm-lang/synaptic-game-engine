# D3 — DnD Encounter Library

Eight **Cursed Keep** templates cover combat, traps, checks, hazards, duels, puzzles, a boss, and a random event. Each declares the d20 ability/skill, DC, modifier source, advantage/disadvantage conditions, and consequences.

## Library Index

| ID | Template | Role | Max turns | Telegraph channels |
| --- | --- | --- | ---: | --- |
| `cursed-keep.combat.skeletal-retainers` | Skeletal Retainers | trash | 6 | scene |
| `cursed-keep.trap.pendulum-chapel` | Pendulum Chapel Trap | hazard | 4 | scene |
| `cursed-keep.skill.portcullis-oath` | Portcullis Oath Check | skill | 4 | npc |
| `cursed-keep.environmental.black-cistern` | Rising Black Cistern | hazard | 6 | status, scene |
| `cursed-keep.duel.castellans-heir` | Duel with the Castellan’s Heir | duel | 8 | npc |
| `cursed-keep.puzzle.four-saints` | The Four Saints Door | puzzle | 4 | item |
| `cursed-keep.boss.hollow-castellan` | The Hollow Castellan | boss | 12 | scene, npc, status |
| `cursed-keep.random.lantern-pilgrim` | Lantern Pilgrim at the Cross-Stair | random | 4 | scene |

## 1. Skeletal Retainers

Four retainers defend the servants’ hall under a brittle command seal.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** Four place settings gather dust except for fresh bone scratches beneath the table. |
| Stakes | Break, turn, or avoid the retainers before they ring the keep bell.<br>**Fight the skeletal retainers** — The retainers fall and the servants’ hall clears.<br>**Turn the command seal with Religion** — The seal recognizes a higher command and the retainers stand down.<br>**Close the iron service door and reroute** — The party bars the door and accepts a detour. |
| Resolution | `combat`; maximum 6 turns. **Forced terminal:** The party slams the service door after the bell rings; the encounter ends with a detour. |
| Aftermath | Minimum 2 receipt types; supported: dungeon, loot, npc, quest, xp. |
| Biome and window | cursed-keep-interior; eligible turns 1–18; cooldown 6. |


**Prose example.**

> **Telegraph:** Fresh scratches beneath dusty place settings and a taut bell cord reveal the retainers before they rise.
>
> **Stakes:** Fight, invoke the command seal at DC 14, or bar the service door and accept the west-stair detour.
>
> **Resolution:** HP and Keep Alert update each round; turn six forces the door-barred exit rather than indefinite initiative.
>
> **Aftermath:** The ledger marks the hall cleared or rerouted and records milestone progress plus loot, condition, or quest state.

## 2. Pendulum Chapel Trap

A visible pressure seam releases consecrated pendulum blades across the nave.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** Dust stops at a clean line while copper hooks and a ceiling slit frame the nave. |
| Stakes | Disarm, bypass, or abandon the chapel route before the pendulum releases.<br>**Disable the gear train with thieves’ tools** — The gear train locks and the nave opens.<br>**Jam the blades with the iron lectern** — The lectern jams the sweep and the party passes.<br>**Take the flooded sacristy bypass** — The party avoids the trap through a flooded, resource-costly bypass. |
| Resolution | `d20`; maximum 4 turns. **Forced terminal:** The pendulum releases once, damage resolves, and the route opens behind the spent mechanism. |
| Aftermath | Minimum 2 receipt types; supported: dungeon, loot, npc, quest, xp. |
| Biome and window | cursed-keep-interior; eligible turns 2–25; cooldown 9999. |


**Prose example.**

> **Telegraph:** A clean dust line, wall hooks, and the ceiling slit show exactly where the pendulum will sweep.
>
> **Stakes:** Disable at DC 15, jam at DC 13 with the lectern, or spend a torch on the flooded sacristy route.
>
> **Resolution:** A failed disable queues the DC 14 save and closes that panel; at four turns the blade fires once and becomes spent.
>
> **Aftermath:** Receipts mark the hazard disarmed, jammed, bypassed, or triggered and record route, tool, injury, milestone, and item changes.

## 3. Portcullis Oath Check

A speaking portcullis tests whether visitors can prove lawful purpose.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **NPC:** The gate recites three lawful purposes and asks the party to name its witness. |
| Stakes | Convince, recall, or abandon the oath gate before it brands the party trespassers.<br>**State a lawful purpose and name a witness** — The gate accepts the purpose and opens.<br>**Recall the founder’s exception with History** — The forgotten exception compels the portcullis to rise.<br>**Leave for the roof-walk approach** — The party abandons the gate and climbs into the storm. |
| Resolution | `d20`; maximum 4 turns. **Forced terminal:** The gate brands the party and locks; the encounter ends with a removal quest. |
| Aftermath | Minimum 2 receipt types; supported: dungeon, npc, quest, xp. |
| Biome and window | cursed-keep-interior; eligible turns 3–35; cooldown 9999. |


**Prose example.**

> **Telegraph:** The speaking gate lists accepted purposes and asks for a witness, making the social obstacle and proof structure explicit.
>
> **Stakes:** Persuade at DC 14, invoke a known historical exception at DC 12, or take the dangerous roof walk.
>
> **Resolution:** Rejected evidence is logged and cannot be recycled; four turns fill the brand clock and close the gate conclusively.
>
> **Aftermath:** The system records opened access, escort, brand, or detour along with milestone and quest progression.

## 4. Rising Black Cistern

Cursed water rises while the party searches for a drain wheel.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **STATUS:** BLACK WATER 2/6; at full, the lower vault floods.<br>**SCENE:** A rusted chain leads from the drain grille to a wheel above the waterline. |
| Stakes | Open the drain, reach the balcony, or retreat before the cistern fills.<br>**Turn the rusted drain wheel** — The drain opens and the lower vault remains accessible.<br>**Climb to the reliquary balcony** — The party escapes upward but loses the lower route.<br>**Retreat through the intake tunnel** — The party leaves safely but forfeits lower-vault access. |
| Resolution | `d20`; maximum 6 turns. **Forced terminal:** The water fills the chamber and carries the party to the balcony; the lower vault is lost. |
| Aftermath | Minimum 2 receipt types; supported: dungeon, loot, npc, quest, xp. |
| Biome and window | cursed-keep-sublevel; eligible turns 4–45; cooldown 9999. |


**Prose example.**

> **Telegraph:** The visible water clock and chain-to-wheel geometry show both deadline and solution.
>
> **Stakes:** Open the wheel at DC 15, climb at DC 13 and lose the lower route, or retreat and forfeit its loot.
>
> **Resolution:** Every failure raises the water; at six turns the flood carries the party out and permanently resolves the location state.
>
> **Aftermath:** Receipts reconcile water, routes, exhaustion, lower-vault access, milestones, and reliquary rewards.

## 5. Duel with the Castellan’s Heir

A spectral heir demands satisfaction but can be released by proving the true murderer.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **NPC:** The heir names the formal duel law and points to the blood-stained witness gallery. |
| Stakes | Defeat, release, or yield to the heir before the gallery seals.<br>**Fight under the heir’s duel law** — The heir yields and opens the gallery.<br>**Present the kitchen ledger as murder proof** — The heir accepts the proof, releases the duel, and entrusts the signet.<br>**Yield and surrender the stolen signet** — The duel ends and the heir takes the signet. |
| Resolution | `hybrid`; maximum 8 turns. **Forced terminal:** The gallery seals; the heir withdraws and the duel ends with a new route objective. |
| Aftermath | Minimum 3 receipt types; supported: dungeon, npc, quest, xp. |
| Biome and window | cursed-keep-interior; eligible turns 10–60; cooldown 9999. |


**Prose example.**

> **Telegraph:** The heir announces the law, the surrender price, and the evidence gallery before drawing steel.
>
> **Stakes:** Fight, present the kitchen ledger at DC 14 with corroboration, or yield the stolen signet to end the duel.
>
> **Resolution:** Combat changes HP; rejected evidence locks; and the eighth turn seals the gallery and closes the encounter.
>
> **Aftermath:** The outcome records the heir’s durable state, signet ownership, gallery access, milestone progress, and follow-up quest.

## 6. The Four Saints Door

Four movable saint reliefs encode the keep’s order of succession.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **ITEM:** A nursery rubbing names the saints by season, while each relief holds a different harvest tool. |
| Stakes | Open the saint door, spend a bypass resource, or retreat before the curse brands a false succession.<br>**Order the saints using the nursery rubbing** — The correct succession opens the library.<br>**Spend the wax Saint Key** — The consumed key bypasses the sequence and opens the door.<br>**Leave the ancestral wing** — The party leaves and opens a clue-finding objective. |
| Resolution | `d20`; maximum 4 turns. **Forced terminal:** The curse marks a false heir and the door locks; a cleansing quest begins. |
| Aftermath | Minimum 2 receipt types; supported: dungeon, npc, quest, xp. |
| Biome and window | cursed-keep-interior; eligible turns 5–50; cooldown 9999. |


**Prose example.**

> **Telegraph:** The nursery rubbing and harvest tools provide a fair evidence chain for the succession order.
>
> **Stakes:** Solve at DC 13 with inspected symbols, consume the unique wax key, or leave and search for more evidence.
>
> **Resolution:** Wrong arrangements are stored and blocked; after four attempts the false-heir mark commits and the door locks.
>
> **Aftermath:** The receipt preserves solution or bypass method, key state, library access, curse state, milestone, and follow-up.

## 7. The Hollow Castellan

The keep’s ruler alternates martial and oath-bound phases around a visible heart reliquary.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** From the witness gallery, the party sees the heart reliquary, two oath braziers, and the postern stair.<br>**NPC:** The heir warns that the Castellan must answer a true accusation after both braziers go dark.<br>**STATUS:** BOSS RULE: martial and oath phases alternate; repeated tactics lose advantage. |
| Stakes | End the curse, expose the Castellan, or escape before the keep seals its heart.<br>**Extinguish both oath braziers and break the reliquary** — The reliquary breaks and the keep’s curse ends.<br>**Accuse the Castellan with the murder proof** — The true accusation compels confession and dissolves the oath-body.<br>**Escape down the postern stair** — The party escapes while the keep remains cursed. |
| Resolution | `hybrid`; maximum 12 turns. **Forced terminal:** The heart seals and expels the party as oath-bound servants; the fight ends with a liberation quest. |
| Aftermath | Minimum 4 receipt types; supported: dungeon, loot, npc, quest, xp. |
| Biome and window | cursed-keep-heart; eligible turns 25–100; cooldown 9999. |


**Prose example.**

> **Telegraph:** The gallery vista shows braziers, reliquary, and postern while the heir explains the accusation condition and status panel reveals phase rules.
>
> **Stakes:** Break the curse in combat, spend validated murder proof after setup, or escape and leave the keep cursed.
>
> **Resolution:** The heart-seal clock bounds twelve turns; all attacks, proof, and routes mutate state, and the bound creates a liberation quest.
>
> **Aftermath:** Victory or confession emits boss loot, milestone, dungeon, curse, NPC, and quest receipts; retreat and defeat remain durable.

## 8. Lantern Pilgrim at the Cross-Stair

A neutral ghost offers guidance but may be a mimic wearing a pilgrim’s memory.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** The pilgrim’s lantern casts two shadows, one pointing toward a safe stair and one toward a sealed pantry. |
| Stakes | Trust, test, or avoid the pilgrim before the lantern chooses a stair.<br>**Test the pilgrim with Insight** — The party identifies the ghost’s truth and learns the safe stair.<br>**Offer the recovered pilgrim name** — The named spirit becomes a temporary guide.<br>**Avoid both marked stairs** — The party backtracks safely while alert rises. |
| Resolution | `d20`; maximum 4 turns. **Forced terminal:** The lantern chooses and vanishes; the party is placed on one persistent route and the encounter closes. |
| Aftermath | Minimum 2 receipt types; supported: dungeon, npc, quest, xp. |
| Biome and window | cursed-keep-interior; eligible turns 1–80; cooldown 15. |


**Prose example.**

> **Telegraph:** The double shadow turns a random ghost meeting into a readable trust problem.
>
> **Stakes:** Test at DC 12, offer the one-use name at DC 10, or backtrack while accepting alert.
>
> **Resolution:** The apparition changes after every attempt; the fourth turn selects a persistent route and removes the event.
>
> **Aftermath:** The result records route, pilgrim identity, ghost-light, alert, milestone, and any pantry escape hook.
