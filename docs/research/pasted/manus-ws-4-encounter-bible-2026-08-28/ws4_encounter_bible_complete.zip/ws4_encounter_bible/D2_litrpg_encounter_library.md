# D2 — LitRPG Encounter Library

Eight **Summoned Pact** templates use visible tier/HP rules, real flee and parley terminals, deterministic ledger updates, typed loot, and bounded turn windows.

## Library Index

| ID | Template | Role | Max turns | Telegraph channels |
| --- | --- | --- | ---: | --- |
| `summoned-pact.hub-ambush.ashknife-cell` | Ashknife Cell at the Contract Market | ambush | 6 | scene |
| `summoned-pact.dungeon-trash.chain-mites` | Chain-Mite Nest | trash | 4 | scene |
| `summoned-pact.miniboss.covenant-devourer` | Covenant Devourer | elite | 8 | status, item |
| `summoned-pact.boss.null-notary` | The Null Notary | boss | 12 | status, scene, item |
| `summoned-pact.arena-duel.bronze-oath` | Bronze Oath Arena Duel | duel | 10 | npc, status |
| `summoned-pact.faction-raid.glass-binder` | Glass-Binder Faction Raid | raid | 12 | faction, scene, npc |
| `summoned-pact.patrol.seal-wardens` | Seal-Warden Patrol | patrol | 6 | faction, scene |
| `summoned-pact.wandering-elite.unbound-chimera` | Unbound Chimera | elite | 9 | scene, item |

## 1. Ashknife Cell at the Contract Market

Assassins collapse a contract-market ward and strike from shuttered stalls.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** Every contract bell stops on the same note and awnings drop in sequence. |
| Stakes | Survive the cell without letting its paymaster erase the market ledgers.<br>**Break the isolation ward and fight** — The cell is defeated and the market ward stabilizes.<br>**Flee through the archive turnstile** — The player escapes into the warded archive while the market enters lockdown.<br>**Expose the captured Ashknife seal** — The assassins withdraw to protect their paymaster. |
| Resolution | `combat`; maximum 6 turns. **Forced terminal:** At the bound, wardens drag the player through the archive gate; escape succeeds with a cut and market lockdown. |
| Aftermath | Minimum 2 receipt types; supported: dungeon, faction, loot, npc, quest, xp. |
| Biome and window | urban-hub, arcane-market; eligible turns 8–60; cooldown 25. |


**Prose example.**

> **Telegraph:** The contract bells stop together; silk awnings snap down and a dropped coin rolls uphill toward a broken ward.
>
> **Stakes:** Fight to secure the ledgers, flee through the warded archive at a stamina cost, or expose a captured Ashknife seal after the leader is wounded.
>
> **Resolution:** Each exchange changes HP or the danger clock; a failed escape locks that route, and the sixth turn forces a costly archive extraction.
>
> **Aftermath:** Victory records XP, an assassin-tier drop, and restored market security; flight records lockdown and opens the paymaster investigation.

## 2. Chain-Mite Nest

Low-tier pact parasites feed on binding chains in a dungeon passage.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** Nickel-sized chain links tremble and shed translucent shells. |
| Stakes | Clear, bypass, or retreat before the mites sever the corridor binding.<br>**Clear the nest** — The nest is burned out and the corridor becomes safe.<br>**Retreat to the sealed rest niche** — The player retreats to the sealed niche while the nest remains on cooldown.<br>**Lure the brood with scent** — The brood follows the scent vial into a disposal shaft. |
| Resolution | `combat`; maximum 4 turns. **Forced terminal:** The player slams the niche seal and escapes with a bite; the nest remains uncleared. |
| Aftermath | Minimum 2 receipt types; supported: dungeon, faction, loot, npc, quest, xp. |
| Biome and window | crypt-dungeon, chain-vault; eligible turns 1–20; cooldown 5. |


**Prose example.**

> **Telegraph:** Empty shells click across the stones while the binding chains tremble against the draft.
>
> **Stakes:** Fight for XP and crafting chitin, retreat to the sealed niche, or spend the unique scent vial to lure the brood away.
>
> **Resolution:** The low-tier fight lasts at most four turns; every hit updates HP, and any failed route is removed from the next choice set.
>
> **Aftermath:** The receipt grants 70 XP, a trash-table roll, and marks the east corridor cleared or records the unresolved-nest follow-up.

## 3. Covenant Devourer

A rogue summon eats active contracts and grows stronger from unused skills.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **STATUS:** PACT INTEGRITY falls whenever an unused skill icon flickers.<br>**ITEM:** A true-name fragment warms when the ward plates crack. |
| Stakes | Stop the devourer before it steals a permanent skill slot.<br>**Shatter its contract plates** — The devourer collapses and releases the stolen contract names.<br>**Seal the antechamber and withdraw** — The party seals the antechamber and preserves the stolen-name quest.<br>**Speak the recovered true-name fragment** — The fragment restores the original pact and ends hostility. |
| Resolution | `combat`; maximum 8 turns. **Forced terminal:** The devourer consumes one active skill and escapes; the battle ends with a recovery quest. |
| Aftermath | Minimum 3 receipt types; supported: dungeon, faction, loot, npc, quest, xp. |
| Biome and window | arcane-dungeon, contract-vault; eligible turns 8–40; cooldown 20. |


**Prose example.**

> **Telegraph:** Unused skill icons flicker as contract names peel from the walls; the true-name fragment warms when the creature exposes a plate.
>
> **Stakes:** Break six progress segments, retreat behind the antechamber seal, or speak the true name once both ward plates are gone.
>
> **Resolution:** Failed attacks deal ledger damage and advance consumption danger; at turn eight the creature steals one skill and exits, ending the encounter.
>
> **Aftermath:** Victory grants 680 XP, elite pact loot, and releases the stolen names; binding adds Collegium standing and a custodian NPC state.

## 4. The Null Notary

A boss that voids one declared action each phase unless its seal clauses are countered.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **STATUS:** ENCOUNTER RULE: the first repeated action each phase is voided.<br>**SCENE:** Three seal desks face the core and a service vault stands behind the witness rail.<br>**ITEM:** The original summons writ carries the Notary’s unvoided signature. |
| Stakes | Claim the black ledger before the twelfth seal closes.<br>**Break three seal clauses and strike the core** — The Notary is defeated and the black ledger accepts the player as lawful claimant.<br>**Escape through the service vault** — The party reaches the service vault while the Notary claims the ledger.<br>**Present the original summons writ** — The writ compels the Notary to recognize the player and dissolve the fight. |
| Resolution | `combat`; maximum 12 turns. **Forced terminal:** The twelfth seal closes; the Notary claims the ledger and brands the party, then the encounter ends. |
| Aftermath | Minimum 4 receipt types; supported: dungeon, faction, loot, npc, quest, xp. |
| Biome and window | contract-vault, void-court; eligible turns 25–90; cooldown 999. |


**Prose example.**

> **Telegraph:** The status panel reveals the repeated-action void, three seal desks mark the phases, and the signed writ remains bright in the boss’s shadow.
>
> **Stakes:** Win by breaking clauses and the core, flee to the service vault at the cost of the ledger, or compel recognition after breaking the null seal.
>
> **Resolution:** The fight uses eight success and six danger segments with HP accounting; turn twelve commits defeat and an appeal quest rather than continuing.
>
> **Aftermath:** Victory emits XP, guaranteed boss loot, sanctum clearance, and quest/faction receipts; all alternatives produce at least two durable outcomes.

## 5. Bronze Oath Arena Duel

A nonlethal formal duel where crowd favor can enable an honorable draw.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **NPC:** The herald states the surrender, draw, and time-limit rules before the gates lock.<br>**STATUS:** Crowd Favor 2/3; one display of restraint unlocks a draw offer. |
| Stakes | Win the circuit, yield safely, or earn an honorable draw before the gong.<br>**Duel to formal surrender** — The champion yields under arena law and the player takes the bronze circuit.<br>**Yield through the healers’ gate** — The player yields and exits through the healers’ gate.<br>**Spend crowd favor to propose a draw** — The champion accepts a draw that preserves both standings. |
| Resolution | `combat`; maximum 10 turns. **Forced terminal:** The gong ends the match as a draw; standing rises slightly but the champion prize remains locked. |
| Aftermath | Minimum 2 receipt types; supported: dungeon, faction, loot, npc, quest, xp. |
| Biome and window | urban-hub, arena; eligible turns 10–70; cooldown 18. |


**Prose example.**

> **Telegraph:** The herald reads the law aloud while the status pane exposes surrender, draw, and time-limit outcomes.
>
> **Stakes:** Fight to formal surrender, yield through the healers’ gate, or spend three crowd favor after demonstrating restraint.
>
> **Resolution:** HP and crowd favor change each exchange; at ten turns the gong commits a partial draw and permanently closes the match.
>
> **Aftermath:** Victory grants XP and arena loot; a draw grants standing and a rival relationship; defeat opens training rather than a repeat loop.

## 6. Glass-Binder Faction Raid

A three-objective raid on a faction convoy carrying captive summons.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **FACTION:** Intercepted orders show the convoy route and reinforcement turn.<br>**SCENE:** Three wagons display distinct vanguard, cage, and command seals.<br>**NPC:** The commander values one documented exchange above a costly last stand. |
| Stakes | Free the captives before binder reinforcements reach the ravine.<br>**Break the vanguard, cages, and command seal** — The convoy breaks and the captive summons are freed.<br>**Order a withdrawal to the ravine** — The strike team withdraws to the rally point with surviving allies.<br>**Present the route orders and demand exchange** — The commander accepts a documented prisoner exchange. |
| Resolution | `combat`; maximum 12 turns. **Forced terminal:** Reinforcements force a withdrawal; one captive cohort is lost and the encounter closes. |
| Aftermath | Minimum 4 receipt types; supported: dungeon, faction, loot, npc, quest, xp. |
| Biome and window | badlands-road, ravine, fortified-convoy; eligible turns 20–85; cooldown 35. |


**Prose example.**

> **Telegraph:** Intercepted orders reveal the convoy timing; the three seals show objective order, and an ally names the commander’s exchange doctrine.
>
> **Stakes:** Assault all three objectives, order a costly withdrawal, or force an exchange after isolating the escort wagons.
>
> **Resolution:** Success and reinforcement clocks race for at most twelve turns; the bound forces withdrawal and records which captives were lost.
>
> **Aftermath:** Victory pays raid XP, typed loot, faction standing, and the captive quest; other terminals preserve ally and convoy state.

## 7. Seal-Warden Patrol

Collegium wardens inspect active pacts on a controlled road.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **FACTION:** Blue seal-flares mark a scheduled Collegium inspection ahead.<br>**SCENE:** Chalk dust obscures a side gully where ward sigils fail. |
| Stakes | Pass inspection, escape the patrol, or resist confiscation.<br>**Resist confiscation** — The patrol is defeated and the confiscation order is recovered.<br>**Break line of sight in the chalk gully** — The player loses the patrol in a ward-dead gully.<br>**Submit the valid transit writ** — The wardens verify the transit writ and grant safe passage. |
| Resolution | `combat`; maximum 6 turns. **Forced terminal:** The inspection concludes with one unlicensed summon impounded; the patrol leaves. |
| Aftermath | Minimum 2 receipt types; supported: dungeon, faction, loot, npc, quest, xp. |
| Biome and window | controlled-road, chalk-badlands, city-outskirts; eligible turns 4–45; cooldown 12. |


**Prose example.**

> **Telegraph:** Blue seal-flares pulse beyond the bend while chalk dust reveals a ward-dead gully to the west.
>
> **Stakes:** Submit a valid writ for safe passage, flee through the gully, or fight and accept a Collegium standing cost.
>
> **Resolution:** The patrol cannot inspect forever: each exchange changes legality or clocks, and turn six ends with a declared impound result.
>
> **Aftermath:** The receipt records passage, impound, or patrol defeat together with faction, quest, XP, loot, or route changes.

## 8. Unbound Chimera

A roaming three-aspect summon hunts mana signatures across broken highlands.

| Lifecycle phase | Contract |
| --- | --- |
| Telegraph | **SCENE:** Three sets of tracks converge without overlapping shadows.<br>**ITEM:** The founder bell vibrates only when the central track crosses basalt. |
| Stakes | Survive the roaming elite without letting it consume the trail’s mana wells.<br>**Sever its three pact aspects** — The chimera’s three aspects collapse and the highland trail becomes safe.<br>**Mask your signature in the basalt tunnel** — The player masks their signature inside the basalt tunnel.<br>**Ring the founder bell at the exposed aspect** — The founder bell recalls the chimera to its abandoned shrine. |
| Resolution | `combat`; maximum 9 turns. **Forced terminal:** The player burns all mana to mask their signature and escapes into basalt; the chimera resumes roaming later. |
| Aftermath | Minimum 3 receipt types; supported: dungeon, faction, loot, npc, quest, xp. |
| Biome and window | broken-highlands, basalt-fields, ruined-shrine; eligible turns 12–80; cooldown 28. |


**Prose example.**

> **Telegraph:** Three incompatible tracks share one shadow, and the founder bell hums at a basalt tunnel cut into the ridge.
>
> **Stakes:** Sever all aspects, escape by burning mana to mask your signature, or expose the hearing aspect and ring the unique bell.
>
> **Resolution:** The elite lasts at most nine turns; failure advances hunger, and the bound forces a zero-mana escape rather than endless pursuit.
>
> **Aftermath:** Victory grants elite loot and trail clearance; recall changes shrine and settler state; flight creates a roaming cooldown and restoration hook.
